/*
    *** IMPORTANT *** : REFER TO LINE 140 FOR AN EXPLANATION OF THE GAME'S LOGIC.
    
    This file contains all of the necessary code for the choose-your-own story game.
    This project must be run on a Windows system due to the system("pause") function, which is a Windows OS function.

    NOTE: This project is coded somewhat inefficiently, as it was made just for fun when I was first learning coding.
          I know that the use of booleans, structures, and classes could have made this program faster, or at least
          easier to understand.
*/

#include <iostream> // For printing to the screen
#include <ctime>    // For quick time events
using namespace std;

int main()
{
   clock_t now;    // Used to record the player's reaction time during quick time events
   char    choice; // Used to record the player's choice to different scenarios
   string message; // Used to record what the player types during quick time events

   int qte_time = 4 * (int)CLOCKS_PER_SEC; // Default quick time event timer is 4 seconds

   char menuOption = '0'; // Option that the player chooses in the main menu
   char difficulty = '1'; // Difficulty level that can be changed in the main menu.
                          // Higher difficulty level means less time to react during quick time events.

   // Events
   int zombieShot = 0;      // If Cara was shot in the house
   int alcohol    = 0;      // If Connor brought the alcohol with him
   int shortcutSuccess = 0; // If the group successfully took the shortcut
   int JamesAlive = 1;      // If James stayed alive
   int chaseProgress = 0;   // Bella's progress during the chase
   int CaseyInjured = 0;    // Whether Casey got injured
   int CaraDIH = 0;         // If Cara dies in the house during the second attack
   int JosieAlive = 1;      // If Josie is still alive at the end of the story

   // Relationships
   int rThomasCara  = 0; // Thomas and Cara
   int rJackConnor  = 0; // Jack and Connor
   int rCaseyBella  = 0; // Casey and Bella
   int rCaseyBoys   = 0; // Casey and the boys (Jack and Connor)
   int rConnorSarah = 0; // Connor and Sarah
   int rJackSarah   = 0; // Jack and Sarah

   // Status (these are self-explanatory)
   int CaraAlive   = 1;
   int ConnorAlive = 1;
   int SarahAlive  = 1;
   int CaseyAlive  = 1;
   int BellaAlive  = 1;
   int ThomasAlive = 1;
   int JackAlive   = 1;
   
   // Loops through the main options until the player decides to start the game
   do
   {
       // Display main menu
       cout << "\n\nMAIN MENU";
       cout <<   "\n---------";
       cout <<   "\n1. Play";
       cout <<   "\n2. Characters";
       cout <<   "\n3. Change Difficulty";

       // Prompt the player for which menu option they want to choose.
       cout << "\n\nOption: ";
       cin >> menuOption;

       // Display info about the characters.
       if (menuOption == '2')
       {
          cout <<   "\n\nCharacters:";

          cout <<   "\n\nThomas: Rational and tough, Thomas always knows what to do in every situation.";
          cout <<     "\n        Although he is a great leader, he can be a bit bossy at times.";

          cout <<   "\n\nCara:   Cara likes to be taken care of, but when it comes down to it, she can handle herself.";

          cout <<   "\n\nJack:   Jack is a problem-solver  He likes to chat.  Jack will protect his friends at all costs,";
          cout <<     "\n        and is good at making the right decisions when things get tough.";

          cout <<   "\n\nConnor: Connor is often described as a big teddy bear.  Although he can be clueless at times,";
          cout <<     "\n        he means no harm, and just wants everybody to have fun.";

          cout <<   "\n\nSarah:  Likes to act spoiled around friends, but is insecure due to family life.";
          cout <<     "\n        She is often depressed, so she acts helpless to make up for it.";

          cout <<   "\n\nCasey:  Bella's boyfriend.  Growing up, Casey was always the quiet, awkward kid that never";
          cout <<     "\n        had anything to say.  That was before he met Bella.  Since Casey and Bella have met,";
          cout <<     "\n        Bella has helped him to branch out and talk to others his age.";

          cout <<   "\n\nBella:  Casey's girlfriend.  She is extroverted in a polite sort of way.  She is affectionate,";
          cout <<     "\n        yet not spoiled.";

          cout << "\n\n\n";

          system("pause");
       }
       else
       {
           // Prompt the player to choose a difficulty.
           if (menuOption == '3')
           {
               cout << "\n\nDifficulty:";
               cout << "\n\n1. Easy";
               cout << "\n2. Normal";
               cout << "\n3. Hard";
               cout << "\n4. Very Hard\n";

               do
               {
                   cout << "\nOption: ";
                   cin >> difficulty;
               } while (difficulty != '1' && difficulty != '2' && difficulty != '3' && difficulty != '4');

               if (difficulty == '1')
                   qte_time = 7 * (int)CLOCKS_PER_SEC; // Easy: 7 sec qte time

               else if (difficulty == '2')
                   qte_time = 4 * (int)CLOCKS_PER_SEC; // Medium: 4 sec qte time

               else if (difficulty == '3')
                   qte_time = 2 * (int)CLOCKS_PER_SEC; // Hard: 2 sec qte time

               else if (difficulty == '4')
                   qte_time = 1 * (int)CLOCKS_PER_SEC; // Very hard: 1 sec qte time
           }
       }

       system("cls");

       // Let the player know that they did not choose a valid menu option.
       if (menuOption != '1' && menuOption != '2' && menuOption != '3')
       {
           cout << "Invalid option.";
       }
   } while (menuOption != '1');

   /*
                          EXPLANATION OF GAME LOGIC
   ----------------------------------------------------------------------

   Each scene will have an info screen before it starts.  This screen
   tells the player which characters are in the scene, and where the
   scene takes place.

   Also, outside of info screens, the game will always
   display which character you are making decisions for.
   This is indicated by the "Controlling: [PERSON]" at
   the top of the screen.

   The "pause >nul" commands are to allow the game to pause
   between every line, giving the player time to read.  The game will
   continue upon the player pressing the any key.  The ">nul" is
   to get rid of the "PRESS ANY KEY TO CONTINUE . . ." text.

   Decisions can affect many things, such as relationships, and who
   stays alive.  On the other hand, quick time events can only affect
   the well-being of the characters, meaning that failing a quick-time
   event can sometimes cause a character to get injured or die.

   Quick time events are implemented using the clock() function.
   At the start of a quick time event, the clock starts counting.
   The game will then wait for the player to type in the required
   input for the quick time event.  After the player types in the
   required input, the clock() function will check the amount of time
   that has elapsed since the start of the quick time event, and compare
   it to the required reaction time (7, 4, 2, or 1 second), depending on
   the difficulty of the game (which can be set in the main menu).
   */

   /*
   -------------------GAME LOGIC STARTS BELOW THIS LINE------------------
   */
    


   // Notify the player that the game is about to start
   cout <<     "Starting Game . . .";

   /*-------------------------------------------------*/
   /*                    Prologue                     */
   /*-------------------------------------------------*/

   // Info screen for prologue
   cout << "\n\nPrologue";
   cout << "\n\nCharacters:";
   cout <<   "\nThomas & Cara (his wife)";
   cout << "\n\nLocation: Tom's Cabin: Living Room\n\n";
   system("pause");
   system("cls");

   // The player will make decisions for Thomas.
   cout << "Controlling: Thomas\n";

   cout << "\n\nTHOMAS: Things have changed so much over these past few months.";
   system("pause >nul");

   cout << "\n\nCARA:   Yeah... I can't believe that all of that stuff happened right near our house!";
   system("pause >nul");

   cout << "\n\n1. DISMISSIVE: Doesn't affect us..."; // Choice 1
   cout <<   "\n2. AGREE:      Yeah it's crazy..."  ; // Choice 2

   do
   {
       cout << "\n\nChoice: ";
       cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice slightly lowers Thomas and Cara's relationship.
   if (choice == '1')
   {
      cout << "\n\nTHOMAS: Yeah, but that stuff has nothing to do with us.";
      cout << "\n\n        *Cara didn't like that.*";
      rThomasCara -= 1;
      system("pause >nul");

      cout << "\n\nCARA:   Are you crazy?  Three people died right next to our property!\n        For all you know, we could end up being suspects!";
      system("pause >nul");
   }

   // This choice is neutral, and doesn't affect the final outcome of the story.
   else if (choice == '2')
   {
      cout << "\n\nTHOMAS: Yeah, it's crazy!  I hear this type of thing on the news all the time,\n        but those type of things never have happened so close to home before.";
      system("pause >nul");

      cout << "\n\nCARA:   ...";
      system("pause >nul");

      cout << "\n\nCARA:   Three dead, two missing... unreal.";
      system("pause >nul");
   }

   cout << "\n\nCARA:   Anyway, I think we should forget about all of this for now and watch some TV.";
   system("pause >nul");

   cout << "\n\nCARA:   Do you want to watch a movie?  Or binge watch a show?";
   system("pause >nul");


   cout << "\n\n1. ENTHUSIASTIC: Watch a movie";   // Choice 1
   cout <<   "\n2. ENTHUSIASTIC: Watch a TV show"; // Choice 2
   cout <<   "\n3. UNINTERESTED: Just go to bed";  // Choice 3

   do
   {
       cout << "\n\nChoice: ";
       cin  >> choice;
   } while (choice != '1' && choice != '2' && choice != '3');

   // This choice slightly raises Thomas and Cara's relationship.
   if (choice == '1')
   {
      cout << "\n\nTHOMAS: Watching a movie sounds relaxing right now.";
      rThomasCara += 1;
      system("pause >nul");

      cout << "\n\nCARA:   Okie-dokie!  Can you turn on the TV?";
      system("pause >nul");

      cout << "\n\nTHOMAS: Yep.";
      system("pause >nul");

      cout << "\n\n        Thomas walks over to the TV and turns it on.";
      system("pause >nul");
   }

   // This choice significantly raises Thomas and Cara's relationship.
   // (Cara likes to binge watch Netflix shows.)
   else if (choice == '2')
   {
      cout << "\n\nTHOMAS: You know what... let's Netflix and chill for a bit.";
      rThomasCara += 2;
      system("pause >nul");

      cout << "\n\nCARA:   That's what I was thinking!  Can you turn on the TV?";
      system("pause >nul");

      cout << "\n\nTHOMAS: Yep.";
      system("pause >nul");

      cout << "\n\n        Thomas walks over to the TV and turns it on.";
      system("pause >nul");
   }

   // This choice significantly lowers Thomas and Cara's relationship.
   else if (choice == '3')
   {
      cout << "\n\nTHOMAS: I had a long work day today and sleep sounds awfully good right now.";
      cout <<   "\n        I think we should just go to bed and... you know... get down to business.";
      cout << "\n\n        *Cara didn't like that.*";
      rThomasCara -= 2;
      system("pause >nul");

      cout << "\n\nCARA:   Boring!  It's not like watching TV uses energy, you know.  Can we just watch one episode of a show first?";
      system("pause >nul");

      cout << "\n\nTHOMAS: Alright...";
      system("pause >nul");

      cout << "\n\nCARA:   I'll turn on the TV.";
      system("pause >nul");

      cout << "\n\n        Cara walks over to the TV and turns it on.";
      system("pause >nul");
   }

   // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   cout << "Controlling: Thomas\n";

   cout << "\n\n        Slow footsteps can be heard coming from outside.";
   system("pause >nul");

   cout << "\n\nTHOMAS: (whispering) Did you hear that?";
   system("pause >nul");

   cout << "\n\nCARA:   (whispering) Should we check what it is?";
   system("pause >nul");

   cout << "\n\nCARA:   (whispering) Maybe we should grab our shotgun first.";
   system("pause >nul");

   cout << "\n\n1. Investigate";  // Choice 1
   cout <<   "\n2. Grab shotgun"; // Choice 2

   do
   {
       cout << "\n\nChoice: ";
       cin  >> choice;
   } while (choice != '1' && choice != '2');

   // If Thomas decides to investigate, it takes him longer to retrieve the shotgun.
   // This means that the player will have to pass a quick time event in order to save Cara.
   if (choice == '1')
   {
      cout << "\n\n        Thomas looks through the back window to investigate the noise.\n        There is a zombie-looking apparition outside, holding a dagger.\n        It is covered in dirt and is missing clumps of hair and some teeth.";
      system("pause >nul");

      cout << "\n\nTHOMAS: Grab the shotgun!";
      system("pause >nul");

      cout << "\n\n        Thomas and Cara run to grab the shotgun.";
      system("pause >nul");

      cout << "\n\n        Thomas and Cara successfully unlock the safe and retrieve the shotgun, and return to investigate the noise.";
      system("pause >nul");

      cout << "\n\n        They return to find that the zombie has broken inside.";
      system("pause >nul");
   }

   // If Thomas decides to grab the shotgun, he is able to face the zombie more quickly, giving him a clear shot.
   // This can allow the player to potentially bypass the quick time event.
   else if (choice == '2')
   {
      cout << "\n\n        Thomas and Cara run to grab the shotgun.";
      system("pause >nul");

      cout << "\n\n        Thomas and Cara successfully unlock the safe and retrieve the shotgun, and return to investigate the noise.";
      system("pause >nul");

      cout << "\n\n        There is a zombie-looking apparition outside the door, holding a dagger.\n        It is covered in dirt and is missing clumps of hair and some teeth.";
      system("pause >nul");

      cout << "\n\n1. Shoot";    // Choice 1
      cout <<   "\n2. Threaten"; // Choice 2

      do
      {
         cout << "\n\nChoice: ";
         cin  >> choice;
      } while (choice != '1' && choice != '2');

      // Thomas is able to shoot the zombie while he has a clear, easy shot.  The zombie is killed.
      if (choice == '1')
      {
         cout << "\n\n        Thomas shoots at the zombie.";
         system("pause >nul");

         cout << "\n\n        The shot hits the zombie's shoulder, and the zombie stumbles back, making an inhuman screech.";
         system("pause >nul");

         cout << "\n\n        The zombie slowly turns around and runs back into the woods.";
         zombieShot = 1;
         system("pause >nul");
      }

      // Thomas threatens the zombie, causing him to miss the small window of time where he has a clear shot.
      else if (choice == '2')
      {
         cout << "\n\nTHOMAS: Back off! I WILL SHOOT!!!";
         system("pause >nul");

         cout << "\n\n        The zombie ignores the threat and moves closer.";
         system("pause >nul");
      }
   }

   // If Thomas is not able to get a clear shot on the zombie, he will need to perform a quick time event to save Cara.
   if (zombieShot == 0)
   {
      cout << "\n\n        Suddenly, the zombie starts charging towards Cara.";
      system("pause >nul");

      /* ! ! ! ! Q U I C K   T I M E   E V E N T ! ! ! ! */

      cout << "\n\n        Get ready to quickly type a message.\n        Type it fast, and hit ENTER when you are finished to avoid consequences.";
      system("pause >nul");

      cout << "\n\n        TYPE \"SHOOT\":   ";
      now = clock();
      cin >> message;

      // If the quick time event is passed, all characters survive, and the story continues as normal.
      if ((message == "SHOOT" || message == "shoot") && ((clock() - now) < (qte_time * 2)))
      {
         cout << "\n\n        The shot hits the zombie's shoulder, and the zombie stumbles back, making an inhuman screech.";
         system("pause >nul");

         cout << "\n\n        The zombie slowly turns around and runs back into the woods.";
         system("pause >nul");
      }

      // If the quick time event is failed, Cara dies.  The story still continues on.
      else
      {
         cout << "\n\n        The zombie stabs Cara, screeches, and turns towards you.";
         system("pause >nul");

         cout << "\n\nTHOMAS: NO! CARA!!!";
         system("pause >nul");

         cout << "\n\n        Thomas frantically shoots the zombie's shoulder, and the zombie stumbles back, making an inhuman screech.";
         system("pause >nul");

         cout << "\n\n        The zombie slowly turns around and runs back into the woods.";
         system("pause >nul");

         cout << "\n\nCARA:   Why didn't you shoot it?  Why...";
         system("pause >nul");

         cout << "\n\nTHOMAS: (sobbing) I just... didn't want to hurt it... for no reason...";
         system("pause >nul");

         cout << "\n\n        [Cara died.]";
         CaraAlive = 0;
         system("pause >nul");
      }
   }

   // Let the player know that the prologue is complete, and
   // clear the screen, making way for a new scene.
   cout << "\n\n        [Prologue Complete.]";
   system("pause >nul");

   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");

   /*-------------------------------------------------*/
   /*               Chapter 1, Scene 1                */
   /*-------------------------------------------------*/

   // Info screen for Chapter 1, Scene 1
   cout << "Chapter 1, Scene 1";
   cout << "\n\nCharacters:";
   cout <<   "\nJack and Connor (friends)";
   cout << "\n\nLocation: Outside Jack's house\n\n";
   system("pause");
   system("cls");

   // The player will make decisions for Jack.
   cout << "Controlling: Jack\n";

   cout << "\n\nJACK:   Is that Connor?  Finally!  Bro really showed up an hour late.";
   system("pause >nul");

   cout << "\n\n        Connor's car pulls into Jack's driveway and parks, and Connor gets out.";
   system("pause >nul");

   cout << "\n\nCONNOR: Yo Jack!  You ready for tonight?  This campground we're going to sounds real haunted.";
   system("pause >nul");

   cout << "\n\n1. UNCERTAIN:    Is this a good idea..."; // Choice 1
   cout <<   "\n2. ENTHUSIASTIC: I'm ready!"    ;         // Choice 2

   do
   {
       cout << "\n\nChoice: ";
       cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice is neutral, and doesn't affect the final outcome of the story.
   if (choice == '1')
   {
      cout << "\n\nJACK:   Are you sure that going to a campsite where three people were murdered is a good idea?\n        This incident only happened a few months ago, you know.";
      system("pause >nul");

      cout << "\n\nCONNOR: Don't worry man, we'll be fine!\n        Besides, we don't know that they were murdered.";
      system("pause >nul");

      cout << "\n\nJACK:   Their bodies were mangled and lacerated.\n        How would that have happened if it was suicide?";
      system("pause >nul");

      cout << "\n\nCONNOR: (whispering) Don't worry, I have my dad's pistol if anything goes wrong.\n        Don't tell the others though.";
      system("pause >nul");
   }

   // This choice is neutral, and doesn't affect the final outcome of the story.
   else if (choice == '2')
   {
      cout << "\n\nJACK:   Yep, I'm ready.";
      system("pause >nul");

      cout << "\n\nCONNOR: Sounds great man.";
      system("pause >nul");

      cout << "\n\nCONNOR: ...";
      system("pause >nul");

      cout << "\n\nCONNOR: I can't believe that three people went missing there...";
      system("pause >nul");

      cout << "\n\nJACK:   Yeah, and only three months ago.";
      system("pause >nul");

      cout << "\n\nJACK:   Apparently their bodies were mangled and lacerated.\n        Cause of death is still unknown.";
      system("pause >nul");

      cout << "\n\nCONNOR: (whispering) Don't worry though, I got us some protection.";
      system("pause >nul");

      cout << "\n\nCONNOR: (whispering) I have my dad's pistol if anything goes wrong.\n        Don't tell the others though.";
      system("pause >nul");
   }

   // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   cout << "Controlling: Jack\n";

   cout << "\n\nJACK:   (whispering) Please tell me you didn't steal it without his permission.";
   system("pause >nul");

   cout << "\n\nCONNOR: (whispering) I didn't steal it, I just... borrowed it.";
   system("pause >nul");

   cout << "\n\n1. FRUSTRATED:   That wasn't smart...";          // Choice 1
   cout <<   "\n2. THOUGHTFUL:   Maybe we could use the gun..."; // Choice 2

   do
   {
       cout << "\n\nChoice: ";
       cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice significantly lowers Jack and Connor's relationship.
   if (choice == '1')
   {
      cout << "\n\nJACK:   (whispering) I don't think that was a good idea.  Your dad's gonna kill you if he finds out!";
      cout << "\n\n        *Connor didn't like that.*";
      rJackConnor -= 2;
      system("pause >nul");

      cout << "\n\nCONNOR: We are going somewhere that three people died and you don't want a way to defend yourself?";
      system("pause >nul");

      cout << "\n\nJACK:   I don't know... maybe you could've at least asked for permission before taking that gun.";
      system("pause >nul");

      cout << "\n\nCONNOR: If my dad knew how dangerous this place was, I'm sure he would've been fine with it.\n        All of this guilt tripping is not necessary, man!";
      system("pause >nul");
   }

   // This choice significantly raises Jack and Connor's relationship.
   else if (choice == '2')
   {
      cout << "\n\nJACK:   (whispering) Ya know what... smart move.  You never know what's out there.";
      rJackConnor += 2;
      system("pause >nul");

      cout << "\n\nCONNOR: So true man... especially when you're going to a crazy haunted campsite.";
      system("pause >nul");
   }

   // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   cout << "Controlling: Jack\n";

   cout << "\n\nJACK:   Hey Connor, you know if Casey and Bella are coming?";
   system("pause >nul");

   cout << "\n\nCONNOR: Yeah, they're coming.  Driving in a separate car though.";
   system("pause >nul");

   cout << "\n\nCONNOR: You ready to go?  Got all the snacks?";
   system("pause >nul");

   cout << "\n\nJACK:   Yep, I got all the delicious goodies.";
   system("pause >nul");

   cout << "\n\nCONNOR: Hey, you should get your s'mores stuff, you know.\n        S'mores over a campfire sounds amazing.";
   system("pause >nul");

   cout << "\n\n1. EXCITED: Sure does!";               // Choice 1
   cout <<   "\n2. UNSURE:  On a haunted campground?"; // Choice 2

   do
   {
       cout << "\n\nChoice: ";
       cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice slightly raises Jack and Connor's relationship.
   if (choice == '1')
   {
      cout << "\n\nJACK:   Yeah, I could also go for some crisp roasted marshmallows.\n        I'll go and get the s'mores stuff.";
      rJackConnor += 1;
      system("pause >nul");
   }

   // This choice slightly lowers Jack and Connor's relationship.
   else if (choice == '2')
   {
      cout << "\n\nJACK:   Are you sure you want to make s'mores... in a haunted campground... in the open?";
      cout << "\n\n        *Connor didn't like that.*";
      rJackConnor -= 1;
      system("pause >nul");

      cout << "\n\nCONNOR: Are you serious?  Who says we can't have a bit of fun while we're there?  Besides, it's only one night!";
      system("pause >nul");

      cout << "\n\nJACK:   Alright... I'll go and get the s'mores stuff.";
      system("pause >nul");
   }

   // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   cout << "Controlling: Jack\n";

   cout << "\n\n               Jack goes to the kitchen and grabs the supplies to make s'mores.\n               On the way back, his mother is inside the living room relaxing.";
   system("pause >nul");

   cout << "\n\nJACK'S MOTHER: I hope you know what you're getting yourself into.\n               That place is really, really weird.";
   system("pause >nul");

   cout << "\n\nJACK'S MOTHER: If you weren't 18, I definitely wouldn't be letting you do this.";
   system("pause >nul");

   cout << "\n\nJACK:          Yep, I know.";
   system("pause >nul");

   cout << "\n\nJACK'S MOTHER: Don't get yourself killed out there.  I'll see you tomorrow!\n               I love you Jack!";
   system("pause >nul");

   cout << "\n\nJACK:          Yep.  Love you too, mom!";
   system("pause >nul");

   cout << "\n\n               On his way back out, Jack gets a notification from his phone.";
   system("pause >nul");

   cout << "\n\n               The notification is a text from Jack's friend, Casey!\n               \"Hey Jack, our car broke down and had to get towed.\n               We are at a gas station close by, can you pick us up on the way?\"";
   system("pause >nul");  

   cout << "\n\n               Jack returns to the driveway with the necessary supplies to make s'mores.";
   system("pause >nul");

   cout << "\n\nJACK:          Hey Connor, I got a text from Casey.\n               His car broke down and had to get towed, and he needs to be picked up on the way.";
   system("pause >nul");

   cout << "\n\nCONNOR:        Aw man, did you tell him we're coming to pick him up?";
   system("pause >nul");

   cout << "\n\nJACK:          Yeah.";
   system("pause >nul");

   cout << "\n\nCONNOR:        Also, got the s'mores stuff?";
   system("pause >nul");

   cout << "\n\nJACK:          Yep.  Let's head to the camper and get ready for the craziest night of our lives!";
   system("pause >nul");

   cout << "\n\nCONNOR:        Awesome, let's do this bro.";
   system("pause >nul");

   // Let the player know that chapter 1 scene 1 is complete, and
   // clear the screen, making way for a new scene.
   cout << "\n\n        [Scene Complete.]";
   system("pause >nul");

   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");

   /*-------------------------------------------------*/
   /*               Chapter 1, Scene 2                */
   /*-------------------------------------------------*/

   // Info screen for Chapter 1, Scene 2
   cout << "Chapter 1, Scene 2";
   cout << "\n\nCharacters:";
   cout <<   "\nJack, Connor, Casey (Jack and Connor's friend), Bella (Casey's girlfriend)";
   cout << "\n\nLocation: Local Gas Station\n\n";
   system("pause");
   system("cls");

   // The player will make decisions for Casey.
   cout << "Controlling: Casey\n";

   cout << "\n\nCASEY:  They should be here soon.";
   system("pause >nul");

   cout << "\n\nBELLA:  Jack said they would be here in five, and that was five minutes ago.";
   system("pause >nul");

   cout << "\n\n1. HOPEFUL:   They'll be here any minute.";         // Choice 1
   cout <<   "\n2. SARCASTIC: Hope they didn't mean five hours..."; // Choice 2

   do
   {
       cout << "\n\nChoice: ";
       cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice is neutral, and doesn't affect the final outcome of the story.
   if (choice == '1')
   {
      cout << "\n\nCASEY:  Well... that means they'll be arriving just about now!";
      system("pause >nul");
   }

   // This choice slightly raises Casey and Bella's relationship.
   else if (choice == '2')
   {
      cout << "\n\nCASEY:  I really hope he meant five minutes, not five hours.";
      rCaseyBella += 1;
      system("pause >nul");

      cout << "\n\nBELLA:  I didn't know you had a sense of humor...\n        I like it, Casey!";
      system("pause >nul");
   }

   cout << "\n\nBELLA:  Hey, I think that's Connor and Jack right there!";
   system("pause >nul");

   cout << "\n\n        Jack and Connor arrive with the camper, and pull into a parking spot in the back of the gas station.\n        Casey and Bella walk around the gas station to meet them.";
   system("pause >nul");

   cout << "\n\nCONNOR: Yo Casey, what's up!";
   system("pause >nul");

   cout << "\n\nCASEY:  Umm... hey.";
   system("pause >nul");

   cout << "\n\nBELLA:  You ready for tonight, Connor and Jack?";
   system("pause >nul");

   cout << "\n\nJACK:   Pretty much, I can't help being a bit nervous though.";
   system("pause >nul");

   cout << "\n\nCONNOR: It'll be alright.";
   system("pause >nul");

   // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   cout << "Controlling: Casey\n";

   cout << "\n\nCONNOR: Hey, I just got a great idea.  We should pick up a case of beer before we head out.\n        There's a liquor store next door.  You down?";
   system("pause >nul");

   cout << "\n\n1. RELUCTANT: Sure about this?"; // Choice 1
   cout <<   "\n2. AGREE:     Let's party";      // Choice 2

   do
   {
       cout << "\n\nChoice: ";
       cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice opens up the option to prevent Connor from taking alcohol to the campsite.
   // If Connor takes alcohol to the campsite, he might get cursed later on, leading to his death.
   if (choice == '1')
   {
      cout << "\n\nCASEY:  Are you sure that you want to get drunk?\n        Jack told me that the campsite was potentially haunted, so maybe that isn't a good idea.\n        Besides, me and Bella are the only ones over 21.";
      rCaseyBoys -= 1;
      system("pause >nul");

      cout << "\n\nCONNOR: Come on, man!  When else will we get a chance like this?";
      system("pause >nul");

      cout << "\n\n1. AGREE:    Alright.";
      cout <<   "\n2. DISAGREE: Not doing it.";
      do
      {
         cout << "\n\nChoice: ";
         cin  >> choice;
      } while (choice != '1' && choice != '2');

      // This choice does not have an immediate effect, but it might cause Connor
      // to get cursed later, leading to his death.
      // In addition, Casey's relationship with Jack and Connor will raise slightly,
      // but this will not matter, since Connor will die.
      if (choice == '1')
      {
         cout << "\n\nCASEY:  Okay... but don't blame me if something goes wrong.";
         rCaseyBoys += 1;
         alcohol = 1;
         system("pause >nul");
         choice = '0';
      }

      // Connor will not take alcohol to the campsite, possibly saving his life later on.
      else if (choice == '2')
      {
         cout << "\n\nCASEY:  Um... I'm gonna have to say no.  That is an awful idea.";
         system("pause >nul");

         cout << "\n\nCONNOR: Aw man...";
         system("pause >nul");
         choice = '0';
      }
   }

   // This choice does not have an immediate effect, but it might cause Connor
   // to get cursed later, leading to his death.
   // In addition, Casey's relationship with Jack and Connor will raise slightly,
   // but this will not matter, since Connor will die.
   else if (choice == '2')
   {
      cout << "\n\nCASEY:  Alright, let's get to it!";
      rCaseyBoys += 1;
      alcohol = 1;
      system("pause >nul");
   }

   // If the player allows Connor to get alcohol, he will go and buy alcohol.
   if (alcohol == 1)
   {
      cout << "\n\n        Casey and Bella travel to the liquor store across the street and return with a case of beer.";
      system("pause >nul");

      cout << "\n\nJACK:   Yo this is sick!  Thanks guys!";
      system("pause >nul");

      cout << "\n\nBELLA:  No problem.  It's on the house for tonight.";
      system("pause >nul");

      cout << "\n\nCONNOR: Thanks Bella!";
      system("pause >nul");
   }

   // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   cout << "Controlling: Casey\n";

   cout << "\n\nBELLA:  Hey, I just got a text from Sarah!";
   system("pause >nul");

   cout << "\n\nCONNOR: Don't tell me you invited her... there's no room in the camper!\n        She will have to sleep on the floor in a sleeping bag.";
   system("pause >nul");

   cout << "\n\nBELLA:  Yeah... she is coming with us, and she is bringing a sleeping bag.";
   system("pause >nul");

   cout << "\n\nCONNOR: Alright, man...";
   system("pause >nul");

   cout << "\n\nBELLA:  I told her we are at the gas station.  She'll be here in ten minutes.";
   system("pause >nul");

   cout << "\n\n        ...";
   system("pause >nul");

   cout << "\n\n        [20 minutes later...]";
   system("pause >nul");

   cout << "\n\nBELLA:  I swear, she said it would be ten minutes.";
   system("pause >nul");

   cout << "\n\n1. IMPATIENT:  We have to go..."; // Choice 1
   cout <<   "\n2. RESIGNED:   Okay.";            // Choice 2

   do
   {
       cout << "\n\nChoice: ";
       cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice significantly lowers Casey and Bella's relationship.
   if (choice == '1')
   {
      cout << "\n\nCASEY:  Are you serious, Bella?  We have to go!";
      cout << "\n\n        *Bella didn't like that.*";
      rCaseyBella -= 2;
      system("pause >nul");

      cout << "\n\nBELLA:  Come on, Casey!  Give it a few more minutes.";
      system("pause >nul");
   }

   // This choice is neutral, and doesn't affect the final outcome of the story.
   else if (choice == '2')
   {
      cout << "\n\nCASEY:  Okay, we can wait a bit longer.";
      system("pause >nul");
   }

   cout << "\n\nJACK:   Hey, would that be her right there pulling in?";
   system("pause >nul");

   cout << "\n\nCONNOR: Yes it would!";
   system("pause >nul");

   cout << "\n\n        A car pulls into the parking lot, driven by one of Sarah's friends.\n        Sarah says a quick goodbye to her friend, and walks over to the camper.";
   system("pause >nul");
   
   // The screen is cleared, and the character that the player controls switches to Connor.
   cout << "\n\n        [Switching characters...]";
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   cout << "Controlling: Connor\n";

   cout << "\n\nSARAH:  You guys ready to rock and roll?";
   system("pause >nul");

   cout << "\n\nCONNOR: For sure!";
   system("pause >nul");

   cout << "\n\nSARAH:  Tonight's gonna be a wild night, huh...\n        You guys better have brought extra drinks for me!";
   system("pause >nul");

   cout << "\n\n1. ANNOYED:  Come on...";          // Choice 1
   cout <<   "\n2. CHEERFUL: We have extra food."; // Choice 2

   do
   {
       cout << "\n\nChoice: ";
       cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice slightly lowers Connor and Sarah's relationship.
   if (choice == '1')
   {
      cout << "\n\nCONNOR: Come on man, you aren't seriously planning on eating all night, are you?";
      cout << "\n\n        *Sarah didn't like that.*";
      rConnorSarah -= 1;
      system("pause >nul");

      cout << "\n\nSARAH:  What if I was planning on that, though?";
      system("pause >nul");

      cout << "\n\nBELLA:  Hey, that's not a bad idea.  Maybe I'll join you.";
      system("pause >nul");
   }

   // This choice slightly raises Connor and Sarah's relationship.
   else if (choice == '2')
   {
      cout << "\n\nCONNOR: Yeah, man, we got extras.";
      rConnorSarah += 1;
      system("pause >nul");

      cout << "\n\nSARAH:  Awesome.";
      system("pause >nul");
   }

   cout << "\n\nSARAH:  Am I the only one who is totally creeped out by this place we're going to?";
   system("pause >nul");

   cout << "\n\nBELLA:  You're not alone.  This seems like a terrible idea, but think about it... what else do we have to do?";
   system("pause >nul");

   cout << "\n\n1. IGNORANT:   We'll be fine...";         // Choice 1
   cout <<   "\n2. THOUGHTFUL: We should be cautious..."; // Choice 2

   do
   {
       cout << "\n\nChoice: ";
       cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice is neutral, and doesn't affect the final outcome of the story.
   if (choice == '1')
   {
      cout << "\n\nCONNOR: We'll be fine.  In tonight and out tomorrow.  No worries, man.";
      system("pause >nul");

      cout << "\n\nJACK:   You've been saying that since you came over, but how sure can you really be?";
      system("pause >nul");

      cout << "\n\nCONNOR: Come on, let's just have a fun night and not worry about it.\n        No parents around, we can do whatever we want!";
      system("pause >nul");
   }

   // This choice slightly raises Connor and Sarah's relationship.
   else if (choice == '2')
   {
      cout << "\n\nCONNOR: We should be fine, but we should be careful.\n        We need to lock the doors when its late at night, or we could become the next disappearances.";
      rConnorSarah += 1;
      system("pause >nul");

      cout << "\n\nJACK:   That's the first sensible thing you've said today!  I'm impressed!";
      system("pause >nul");

      cout << "\n\nCONNOR: Dude... no it's not.";
      system("pause >nul");
   }

   cout << "\n\nJACK:   Anyway, ready to hit the road, you guys?";
   system("pause >nul");

   cout << "\n\nCASEY:  Yep!";
   cout << "\n\nSARAH:  Yeah!";
   cout << "\n\nCONNOR: For sure.";
   system("pause >nul");

   // Let the player know that chapter 1 scene 2 is complete, and
   // clear the screen, making way for a new scene.
   cout << "\n\n        [Scene Complete.]";
   cout << "\n\n        [Chapter 1 Complete.]";
   system("pause >nul");

   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");

   /*-------------------------------------------------*/
   /*               Chapter 2, Scene 1                */
   /*-------------------------------------------------*/

   // Info screen for Chapter 2, Scene 1
   cout << "Chapter 2, Scene 1";
   cout << "\n\nCharacters:";
   cout <<   "\nJack (driving), Connor";
   cout << "\n\nLocation: In the camper, on the way to the campsite\n\n";
   system("pause");
   system("cls");

   // The player will make decisions for Jack.
   cout << "Controlling: Jack\n";

   cout << "\n\nSARAH:  Are we almost there yet?";
   system("pause >nul");

   cout << "\n\n1. INSTRUCTIVE: Patience..."; // Choice 1
   cout <<   "\n2. CALM:        Yes.";        // Choice 2

   do
   {
       cout << "\n\nChoice: ";
       cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice significantly lowers Jack and Sarah's relationship,
   // and slightly raises Connor and Sarah's relationship.
   if (choice == '1')
   {
      cout << "\n\nJACK:   Patience, Sarah.  We'll be there soon.";
      cout << "\n\n        *Sarah didn't like that.*";
      rJackSarah -= 2;
      system("pause >nul");

      cout << "\n\nSARAH:  Did I ask you to be condescending?";
      system("pause >nul");

      cout << "\n\nJACK:   Did I ask you to add your annoying comments Sarah?\n        You've already asked that question like... 10 times.";
      system("pause >nul");

      cout << "\n\nCONNOR: Chill out, man!";
      rConnorSarah += 1;
      system("pause >nul");

      cout << "\n\nJACK:   ...";
      system("pause >nul");
   }

   // This choice slightly raises Jack and Sarah's relationship.
   else if (choice == '2')
   {
      cout << "\n\nJACK:   Yes, Sarah, we will be there soon.";
      rJackSarah += 1;
      system("pause >nul");

      cout << "\n\nSARAH:  Alright...";
      system("pause >nul");
   }

   cout << "\n\nCONNOR: Hey Jack!  That's a shortcut right there.\n        If you make two left turns, we can get there much faster than the normal route.";
   system("pause >nul");

   cout << "\n\n1. COMPLIANT: Let's do it.";       // Choice 1
   cout <<   "\n2. LOGICAL:   Not a good idea..."; // Choice 2

   do
   {
       cout << "\n\nChoice: ";
       cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice slightly raises Jack and Connor's relationship.
   // In addition, this choice also triggers a series of quick time events, which,
   // if all completed properly, allow the group to arrive at the campsite
   // in time to save James.
   if (choice == '1')
   {
      cout << "\n\nJACK:   Okay, let's do it.";
      rJackConnor += 1;
      system("pause >nul");

      cout << "\n\nCONNOR: Be careful!  Turn's coming up!";
      system("pause >nul");

      /* ! ! ! ! Q U I C K   T I M E   E V E N T ! ! ! ! */
      cout << "\n\n        TYPE \"LEFT\":   ";
      now = clock();
      cin >> message;

      // If the first quick time event is passed, the player will be prompted with a second quick time event.
      if ((message == "LEFT" || message == "left") && ((clock() - now) < qte_time))
      {
         cout << "\n\n        You successfully took the turn.";
         shortcutSuccess = 1;
         system("pause >nul");

         cout << "\n\nCONNOR: Woah, that turn was quick.\n        Hey, next turn's coming up!";
         system("pause >nul");

         /* ! ! ! ! Q U I C K   T I M E   E V E N T ! ! ! ! */
         cout << "\n\n        TYPE \"LEFT\":   ";
         now = clock();
         cin >> message;

         // If the second quick time event is passed, the group will arrive at the campsite in time to save James.
         if ((message == "LEFT" || message == "left") && ((clock() - now) < qte_time))
         {
            cout << "\n\n        You successfully took the turn.";
            shortcutSuccess = 2;
            system("pause >nul");

            cout << "\n\nCONNOR: Hey, we made it!  Good job, Jack!";
            system("pause >nul");
         }
         // If the quick time event is failed, the group will not arrive at the campsite in time to save James.
         else
         {
            cout << "\n\nCONNOR: Aw man, missed it.  That's alright, we will take the main road.";
            shortcutSuccess = 0;
            system("pause >nul");
         }
      }
      // If the quick time event is failed, the group will not arrive at the campsite in time to save James.
      else
      {
         cout << "\n\nCONNOR: Aw man, missed it.  That's alright, we will take the main road.";
         system("pause >nul");
      }
   }

   // This choice will cause the group to arrive at the campsite a bit later.
   // They will not arrive in time to save James.
   else if (choice == '2')
   {
      cout << "\n\nJACK:   Maybe we shouldn't take a risky shortcut, I don't want us to die... yet.";

      cout << "\n\nCONNOR: Gotcha, man.";
      system("pause >nul");
   }

   cout << "\n\n        The camper continues down the road towards the campsite.";
   system("pause >nul");

   // Let the player know that chapter 2 scene 1 is complete, and
    // clear the screen, making way for a new scene.
   cout << "\n\n        [Scene Complete.]";
   system("pause >nul");

   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");

   /*-------------------------------------------------*/
   /*               Chapter 2, Scene 2                */
   /*-------------------------------------------------*/

   // Info screen for Chapter 2, Scene 2
   cout << "Chapter 2, Scene 2";
   cout << "\n\nCharacters:";
   cout <<   "\nJack, Connor, Casey, Bella, Sarah";
   cout << "\n\nLocation: At the campsite\n\n";
   system("pause");
   system("cls");

   // The player will make decisions for Jack.
   cout << "Controlling: Jack\n";

   cout << "\n\n        ...";
   system("pause >nul");

   // If the group successfully pulled off the shortcut, they will meet a
   // frantic James upon reaching the campsite.
   if (shortcutSuccess == 2)
   {
      cout << "\n\n        5 minutes later...";
      system("pause >nul");

      cout << "\n\n        The camper pulls into the campsite, and parks in a grove between some trees.";
      system("pause >nul");

      cout << "\n\n        Before there is time for anyone to leave the camper, a man starts running towards the camper.";
      system("pause >nul");

      cout << "\n\n1. CAUTIOUS:    What do you want?"; // Choice 1
      cout <<   "\n2. THREATENING: Back off!";         // Choice 2

      do
      {
         cout << "\n\nChoice: ";
         cin  >> choice;
      } while (choice != '1' && choice != '2');

      // This choice is neutral, and doesn't affect the final outcome of the story.
      if (choice == '1')
      {
         cout << "\n\nJACK:   What do you want?";
         system("pause >nul");

         cout << "\n\n???:    (frantic) I was just being chased by something, I swear!\n        I don't think it likes large groups of people, because when your camper pulled in, it ran away.";
         system("pause >nul");
      }

      // This choice is neutral, and doesn't affect the final outcome of the story.
      else if (choice == '2')
      {
         cout << "\n\nJACK:   Hey!  Don't come any closer!";
         system("pause >nul");

         cout << "\n\n???:    (frantic) Something was chasing me!  I'm just trying to take cover!";
         system("pause >nul");

         cout << "\n\nJACK:   Alright...";
         system("pause >nul");
      }

      cout << "\n\nJAMES:  Hey, the name's James.";
      system("pause >nul");

      cout << "\n\nJACK:   Nice to meet you.";
      cout << "\n\nCONNOR: Nice to meet ya.";
      system("pause >nul");

      cout << "\n\nJAMES:  By the way, I'm heading out in a few hours.\n        Mind if I park my car near you guys so I don't get attacked again?";
      system("pause >nul");

      cout << "\n\n1. AGREE";    // Choice 1
      cout <<   "\n2. DISAGREE"; // Choice 2

      do
      {
         cout << "\n\nChoice: ";
         cin  >> choice;
      } while (choice != '1' && choice != '2');

      // This choice is neutral, and doesn't affect the final outcome of the story.
      if (choice == '1')
      {
         cout << "\n\nJACK:   Yeah, go ahead!";
         system("pause >nul");

         cout << "\n\nJAMES:  Thanks a lot, bro.";
         system("pause >nul");

         cout << "\n\n        { CLEARING SCREEN... }";
         system("pause >nul");
         system("cls");
         cout << "Controlling: Jack\n";

         cout << "\n\nJAMES:  Hey, you guys from around here?";
         system("pause >nul");

         cout << "\n\nJACK:   Not really, we drove a couple of hours to get here.";
         system("pause >nul");

         cout << "\n\nJAMES:  Oh, then you wouldn't know, then.";
         system("pause >nul");

         cout << "\n\nJAMES:  Everyone who comes here knows about the incident a few months ago, but some information is more... local.";
         system("pause >nul");

         cout << "\n\nJAMES:  The two people who went missing on that night... well... there have been rumors by locals that they have been spotted.";
         system("pause >nul");

         cout << "\n\nJACK:   Then why have they not been found?";
         system("pause >nul");

         cout << "\n\nJAMES:  Apparently, two things.  They have gone absolutely insane, and they are not recognizable any more.";
         system("pause >nul");

         cout << "\n\nJACK:   Would they still be on this campsite?";
         system("pause >nul");

         cout << "\n\nJAMES:  Well... that would explain what was chasing me.\n        I don't think they like people in groups, though.  Just stick together.";
         system("pause >nul");

         cout << "\n\nJACK:   Hey Connor, are you sure we shouldn't just turn around and leave?";
         system("pause >nul");

         cout << "\n\nCONNOR: Uhh... no, dude, we can take on two insane people.  That's like... nothing.\n        Like he said, just stick together, and carry a weapon.";
         system("pause >nul");
      }

      // Parking his car in an isolated spot away from the rest of the group causes James to be attacked later on, leading to his death.
      else if (choice == '2')
      {
         cout << "\n\nJACK:   Sorry, I don't want you to ruin our fun.";
         system("pause >nul");

         cout << "\n\nJAMES:  ...";
         system("pause >nul");

         cout << "\n\nJAMES:  ARE YOU SERIOUS?";
         system("pause >nul");

         cout << "\n\nJAMES:  Okay... (grumbles something angry to himself)";
         system("pause >nul");
         JamesAlive = 0;
      }

      cout << "\n\n        James leaves to return to his car.";
      system("pause >nul");

      // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
      cout << "\n\n        { CLEARING SCREEN... }";
      system("pause >nul");
      system("cls");
      cout << "Controlling: Jack\n";
   }
   // If the group did not pull off the shortcut, they will not arrive in time to save James.
   else
   {
      cout << "\n\n        10 minutes later...";
      system("pause >nul");

      cout << "\n\n        The camper pulls into the campsite, and parks on the side of a grove, between some trees.";
      system("pause >nul");
   }

   // Set James's status to dead if the shortcut was not pulled off.
   if (!(shortcutSuccess == 2))
   {
      JamesAlive = 0;
   }

   cout << "\n\n        Everyone leaves the camper.  There is a small campfire in the middle of the grove.";
   system("pause >nul");

   cout << "\n\nCONNOR: Campfire time, bros?  Oh wait... we need to actually make a campfire first.";
   system("pause >nul");

   cout << "\n\nCONNOR: First, anyone got a lighter?";
   system("pause >nul");

   cout << "\n\nCASEY:  Yeah, I got one.  Me and Bella will gather sticks, and the rest of you can gather leaves and pine needles.";
   system("pause >nul");

   cout << "\n\n1. OPTIMISTIC:  Sounds good!";     // Option 1
   cout <<   "\n2. PESSIMISTIC: This won't work."; // Option 2

   do
   {
       cout << "\n\nChoice: ";
       cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice slightly raises Casey's relationship with Jack and Connor.
   if (choice == '1')
   {
      cout << "\n\nJACK:   Sounds like a plan!";
      rCaseyBoys += 1;
      system("pause >nul");
   }

   // This choice slightly lowers Casey's relationship with Jack and Connor.
   else if (choice == '2')
   {
      cout << "\n\nJACK:   Leaves and pine needles won't keep a fire going for very long.";
      cout << "\n\n        *Casey didn't like that.*";
      rCaseyBoys -= 1;
      system("pause >nul");

      cout << "\n\nBELLA:  I think it's a perfectly good idea.";
      rCaseyBella += 1;
      system("pause >nul");

      cout << "\n\nJACK:   Alright...";
      system("pause >nul");
   }

   cout << "\n\n        The group gathers the necessary materials, and Casey starts the fire with his lighter.";
   system("pause >nul");

   // The screen is cleared, and the character that the player controls switches to Casey.
   cout << "\n\n        [Switching characters...]";
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   cout << "Controlling: Casey\n";

   cout << "\n\nCONNOR: You know, dude, it's a clear night, and we're in the middle of nowhere.\n        I mean... look up at the sky, it sure is incredible.";
   system("pause >nul");

   cout << "\n\nSARAH:  Wow, you can see like... every single star in the sky!  Where I live, there's way too much light pollution to see anything like this.";
   system("pause >nul");

   cout << "\n\nBELLA:  Yeah Sarah, your neighboorhood is quite tightly packed.";
   system("pause >nul");

   cout << "\n\nJACK:   Hey, that's the Big Dipper, right there! (points)";
   system("pause >nul");

   cout << "\n\nCONNOR: It kinda looks like a frying pan.";
   system("pause >nul");

   cout << "\n\nJACK:   I mean... close, but it's supposed to be a ladle.";
   system("pause >nul");

   cout << "\n\nCONNOR: Like a record label?  I want one of those.";
   system("pause >nul");

   cout << "\n\nJACK:   (chuckles) No, a ladle, it's kinda like a ice cream scoop but larger.";
   system("pause >nul");

   cout << "\n\nCONNOR: Hmm, never heard of that.";
   system("pause >nul");

   // If Connor brought alcohol to the campsite, he will try to convince the player to allow him to drink it.
   if (alcohol == 1)
   {
      cout << "\n\nCONNOR: Hey, I could really go for some fresh beer right now.  Anyone else want some?";
      system("pause >nul");

      cout << "\n\nCONNOR: Casey and Bella?";
      system("pause >nul");

      cout << "\n\nCASEY:  I don't drink.";
      cout << "\n\nBELLA:  Same.";
      system("pause >nul");

      cout << "\n\nCONNOR: Sarah?";
      system("pause >nul");

      cout << "\n\nSARAH:  I'm just savoring the moment right now.  Maybe in an hour or so.";
      system("pause >nul");

      cout << "\n\nJACK:   I'm with Sarah on this one.";
      system("pause >nul");

      // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
      cout << "\n\n        { CLEARING SCREEN... }";
      system("pause >nul");
      system("cls");
      cout << "Controlling: Casey\n";

      cout << "\n\nCONNOR: Okay, so just me then?";
      system("pause >nul");

      cout << "\n\n1. INTERVENE: Don't drink right now..."; // Choice 1
      cout <<   "\n2. DO NOTHING";                          // Choice 2

      do
      {
         cout << "\n\nChoice: ";
         cin  >> choice;
      } while (choice != '1' && choice != '2');

      // If the player does not allow Connor to drink the alcohol, Connor will try to convince the player one more time.
      if (choice == '1')
      {
         cout << "\n\nCASEY:  No one else is gonna drink yet, why don't you wait a bit and enjoy yourself?";
         cout << "\n\n        *Connor didn't like that.*";
         rCaseyBoys -= 1;
         system("pause >nul");

         cout << "\n\nCONNOR: Dude, I'm way too hyper right now.\n        According to my friends, I'm way cooler when I'm drunk.";
         system("pause >nul");

         cout << "\n\nCONNOR: Seriously, can I grab a drink?";
         system("pause >nul");

         cout << "\n\n1. INSISTENT: No!";
         cout <<   "\n2. LENIENT:   Go ahead...";

         do
         {
            cout << "\n\nChoice: ";
            cin  >> choice;
         } while (choice != '1' && choice != '2');

         // If the player does not allow Connor to drink the alcohol again, he will reluctantly agree.
         // This saves his life, and prevents him from getting cursed.
         if (choice == '1')
         {
            cout << "\n\nCASEY:  No!  We don't know what's out there.  Let's stay sober... for now.";
            system("pause >nul");

            cout << "\n\nCONNOR: Aw man... alright.";
            system("pause >nul");
         }

         // If the player allows connor to drink alcohol, he will get cursed.  This will cause him to
         // die in the next scene.
         else if (choice == '2')
         {
            cout << "\n\nCASEY:  Okay, go ahead...";
            system("pause >nul");

            cout << "\n\nCONNOR: My gosh, thank you! (sigh)";
            system("pause >nul");

            cout << "\n\n        Connor grabs a glass of beer out of the van, returns to the campfire, and begins to drink it.";
            system("pause >nul");
            ConnorAlive = 0;
         }
      }

      // If the player allows connor to drink alcohol, he will get cursed.  This will cause him to
      // die in the next scene.
      else
      {
         cout << "\n\n        Connor grabs a glass of beer out of the van, returns to the campfire, and begins to drink it.";
         system("pause >nul");
         ConnorAlive = 0;
      }
   }

   // If Connor did not bring alcohol to the campsite, this conversation will ensue...
   else
   {
      cout << "\n\nCONNOR: Well, I could go for some fresh beer right now, but this dude Casey over here said no.";
      system("pause >nul");

      cout << "\n\n1. APOLOGETIC: Sorry...";                     // Choice 1
      cout <<   "\n2. RATIONAL:   Alcohol, haunted campsite..."; // Choice 2

      do
      {
         cout << "\n\nChoice: ";
         cin  >> choice;
      } while (choice != '1' && choice != '2');

      // Connor appreciates Casey's sympathy.
      // This choice slightly raises Casey's relationship with Jack and Connor.
      if (choice == '1')
      {
         cout << "\n\nCASEY:  I'm sorry, it just didn't seem like a good idea.\n        Didn't mean to spoil the fun.";
         rCaseyBoys += 1;
         system("pause >nul");

         cout << "\n\nCONNOR: It's alright, man.";
         system("pause >nul");
      }

      // This choice slightly lowers Casey's relationship with Jack and Connor.
      else if (choice == '2')
      {
         cout << "\n\nCASEY:  Alcohol on a haunted campsite?  Really?";
         cout << "\n\n        *Connor didn't like that.*";
         rCaseyBoys -= 1;
         system("pause >nul");

         cout << "\n\nCONNOR: Yes, it would've been amazing!";
         system("pause >nul");

         cout << "\n\nCASEY:  Amazingly stupid...";
         system("pause >nul");
      }
   }

   // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   cout << "Controlling: Casey\n";

   cout << "\n\n        Suddenly, the group hears some foorsteps, and then a loud roar coming from behind.";
   system("pause >nul");

   cout << "\n\nSARAH:  Oh no...";
   system("pause >nul");

   cout << "\n\nJACK:   Me and Connor will go to check it out.  Casey, Bella, and-";
   system("pause >nul");

   cout << "\n\nSARAH:  Can I come?";
   system("pause >nul");

   cout << "\n\nJACK:   Alright.";
   system("pause >nul");

   cout << "\n\nBELLA:  While you guys are gone, me and Casey will go on a quick scenic walk.\n        Don't worry, I have a taser with me.";
   system("pause >nul");

   cout << "\n\nCASEY:  I got a pocket knife as well.";
   system("pause >nul");

   cout << "\n\nJACK:   Okay, but seriously, you two.  Be back soon.";
   system("pause >nul");

   cout << "\n\nCASEY:  Will do.";
   system("pause >nul");

   cout << "\n\n        [Scene Complete.]";
   cout << "\n\n        [Chapter 2 Complete.]";
   system("pause >nul");

   // Let the player know that chapter 2 scene 2 is complete, and
// clear the screen, making way for a new scene.
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");

   /*-------------------------------------------------*/
   /*               Chapter 3, Scene 1                */
   /*-------------------------------------------------*/

   // Info screen for Chapter 3, Scene 1
   cout << "Chapter 3, Scene 1";
   cout << "\n\nCharacters:";
   cout <<   "\nJack, Connor, Sarah";
   cout << "\n\nLocation: At the camper\n\n";
   system("pause");
   system("cls");

   // The player will make decisions for Jack.
   cout << "Controlling: Jack\n";

   cout << "\n\n        Connor, Jack, and Sarah head towards the van.";
   system("pause >nul");

   cout << "\n\n        Upon reaching the van, they find smoke coming from the engine,\n        as if it had just been on fire.";
   system("pause >nul");

   cout << "\n\nSARAH:  Oh, no, no, no... how are we going to get back now?";
   system("pause >nul");

   cout << "\n\nCONNOR: I'm gonna open up the engine.";
   system("pause >nul");

   cout << "\n\nJACK:   Grab it from the sides, so you don't get burnt.";
   system("pause >nul");

   // The "if" code block describes what happens if Connor drank the alcohol.
   // The "else" code block describes what happens if Connor did NOT drink the alcohol.
   if (ConnorAlive == 0)
   {
      cout << "\n\nCONNOR: Shut up!";
      system("pause >nul");

      cout << "\n\n1. DIFFUSE:   Calm down..."; // Choice 1
      cout <<   "\n2. SURPRISED: Upset now?";   // Choice 2

      do
      {
         cout << "\n\nChoice: ";
         cin  >> choice;
      } while (choice != '1' && choice != '2');

      // This choice is neutral, and doesn't affect the final outcome of the story.
      if (choice == '1')
      {
         cout << "\n\nJACK:   Woah, calm down, Connor.";
         system("pause >nul");

         cout << "\n\nCONNOR: (laughs) Sure...";
         system("pause >nul");
      }

      // This choice is neutral, and doesn't affect the final outcome of the story.
      else if (choice == '2')
      {
         cout << "\n\nJACK:   Woah!  What got you upset?";
         system("pause >nul");

         cout << "\n\nCONNOR: (laughs) I'm not upset...";
         system("pause >nul");
      }
   }

   cout << "\n\n        Connor lifts up the hood, revealing the engine.\n        The engine is covered in ash, and completely broken.";
   system("pause >nul");

   cout << "\n\nSARAH:  Someone messed with the engine!  Oh no... (sniffles)";
   system("pause >nul");

   cout << "\n\nJACK:   They might still be around here.  I think we need Connor's pistol now.";
   system("pause >nul");

   // The "if" code block describes what happens if Connor drank the alcohol.
   // The "else" code block describes what happens if Connor did NOT drink the alcohol.
   if (ConnorAlive == 0)
   {
      cout << "\n\n        Jack goes inside the van and grabs the pistol out of Connor's bag.\n        Jack pockets the pistol.\n        He returns back outside to meet Connor and Sarah.";
      system("pause >nul");
   }
   else
   {
      cout << "\n\nCONNOR: Yeah, it's about time we grabbed that.";
      system("pause >nul");

      cout << "\n\n        Jack and Connor go inside the van, and Jack grabs the pistol out of Connor's bag.\n        Jack pockets the pistol.\n        They return back outside to meet Sarah.";
      system("pause >nul");
   }

   // The "if" code block describes what happens if Connor drank the alcohol.
   // The "else" code block describes what happens if Connor did NOT drink the alcohol.
   if (ConnorAlive == 0)
   {
      cout << "\n\nJACK:   Already finished your glass of beer, Connor?";
      system("pause >nul");

      cout << "\n\nCONNOR: Yeah, and I think I'm going to get another one.";
      system("pause >nul");

      cout << "\n\n        Connor grabs another glass of beer and returns.";
      system("pause >nul");

      cout << "\n\n        Upon returning, Connor chugs the whole glass of beer and throws it onto the ground, shattering it.";
      system("pause >nul");

      cout << "\n\nCONNOR: You know what... I feel great.  I feel... powerful.";
      system("pause >nul");

      // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
      cout << "\n\n        { CLEARING SCREEN... }";
      system("pause >nul");
      system("cls");
      cout << "Controlling: Jack\n";

      cout << "\n\n        Connor's skin begins convulsing, and his face slowly forms into a menacing grin.\n        Slowly, he turns to face Sarah.";
      system("pause >nul");

      cout << "\n\n        A few seconds later, Connor Suddenly takes a leap at Sarah, and grabs her throat.";
      system("pause >nul");

      cout << "\n\n1. Shoot Connor";    // Choice 1
      cout <<   "\n2. Threaten Connor"; // Choice 2

      do
      {
         cout << "\n\nChoice: ";
         cin  >> choice;
      } while (choice != '1' && choice != '2');

      // If Jack shoots Connor, Connor dies.
      if (choice == '1')
      {
         cout << "\n\n        Jack shoots at Connor.";
         system("pause >nul");

         cout << "\n\n        The shot hits him square in the chest, and he collapses to the ground, coughing blood.";
         rJackSarah += 2;
         system("pause >nul");

         cout << "\n\n        Jack runs over and kneels beside Connor.";
         system("pause >nul");

         cout << "\n\n        It seems that the convulsing has stopped, and Connor is back to himself.";
         system("pause >nul");

         cout << "\n\nCONNOR: You... did what had to be done...";
         system("pause >nul");

         cout << "\n\nJACK:   No, no, stay with me, Connor!  You'll be okay!";
         system("pause >nul");

         cout << "\n\nCONNOR: See you on the flip side, dudes...";
         system("pause >nul");

         cout << "\n\nSARAH:  No!  Connor!";
         system("pause >nul");

         cout << "\n\n        With Jack and Sarah at his side, Connor takes his last breath.";
         system("pause >nul");

         cout << "\n\n        [Connor died.]";
         system("pause >nul");

         cout << "\n\n        A couple of minutes later, Jack and Sarah return to the campfire to wait for Bella and Casey.";
         system("pause >nul");
      }

      // If Jack does not shoot Connor, Connor still dies, but Jack also has to do a quick time event to save Sarah.
      else if (choice == '2')
      {
         cout << "\n\nJACK:   Get your hands off of her or you'll regret it!!";
         system("pause >nul");

         cout << "\n\n        Connor ignores the threat and grabs Sarah's throat even tighter.\n        He seems to be getting stronger.";
         system("pause >nul");

         cout << "\n\nJACK:   Only one option left now...";
         system("pause >nul");

         /* ! ! ! ! Q U I C K   T I M E   E V E N T ! ! ! ! */
         cout << "\n\n        TYPE \"FIRE\":   ";
         now = clock();
         cin >> message;

         // If the quick time event is passed, Sarah is saved and Connor dies.
         if ((message == "FIRE" || message == "fire") && ((clock() - now) < qte_time))
         {
            cout << "\n\n        The shot hits Connor square in the chest, and he collapses to the ground, coughing blood.";
            rJackSarah += 2;
            system("pause >nul");

            cout << "\n\n        It seems that the convulsing has stopped, and Connor is back to himself.";
            system("pause >nul");

            cout << "\n\n        Sarah falls to her knees, possibly hurt, but still breathing.";
            system("pause >nul");

            cout << "\n\n        Seeing that Sarah is okay, Jack runs over to Connor and kneels beside him.";
            system("pause >nul");

            cout << "\n\nCONNOR: You... did what had to be done...";
            system("pause >nul");

            cout << "\n\nCONNOR: See you on the flip side, dudes...";
            system("pause >nul");

            cout << "\n\nJACK:   No, no, stay with me, Connor!  You'll be okay!";
            system("pause >nul");

            cout << "\n\n        With Jack at his side, Connor takes his last breath.";
            system("pause >nul");

            cout << "\n\n        [Connor died.]";
            system("pause >nul");

            cout << "\n\n        A couple of minutes later, Jack and Sarah return to the campfire to wait for Bella and Casey.";
            system("pause >nul");
         }

         // If the quick time event is failed, Sarah and Connor both die.
         else
         {
            cout << "\n\n        Jack misses the shot on Connor, and realizes he is out of ammunition.";
            system("pause >nul");

            cout << "\n\n        He runs back into the van to grab another round, and when he returns, it is too late.\n        Sarah is laying on the ground, her throat split open.";
            system("pause >nul");

            cout << "\n\n        [Sarah died.]";
            system("pause >nul");
            SarahAlive = 0;

            cout << "\n\n        As soon as Jack notices Sarah's body, Connor charges at him.";
            system("pause >nul");

            cout << "\n\n        With no other option left, Jack shoots at Connor.";
            system("pause >nul");

            cout << "\n\n        The shot hits him square in the chest, and he collapses to the ground, coughing blood.";
            system("pause >nul");

            cout << "\n\n        Jack runs over and kneels beside Connor.";
            system("pause >nul");

            cout << "\n\n        It seems that the convulsing has stopped, and Connor is back to himself.";
            system("pause >nul");

            cout << "\n\nCONNOR: You... did what had to be done...";
            system("pause >nul");

            cout << "\n\n        With Jack at his side, Connor takes his last breath.";
            system("pause >nul");

            cout << "\n\n        [Connor died.]";
            system("pause >nul");

            cout << "\n\n        Jack runs over to investigate Sarah's body.  He finds that she isn't breathing.";
            system("pause >nul");

            cout << "\n\n        A couple of minutes later, Jack returns to the campfire alone to wait for Bella and Casey.";
            system("pause >nul");
         }
      }
   }
   else
   {
      cout << "\n\nCONNOR: Hey man, now would be a good time for s'mores, don't you think...";
      system("pause >nul");

      cout << "\n\nSARAH:  Yeah, it would!";
      system("pause >nul");

      cout << "\n\nJACK:   Might as well have them while we're waiting for Casey and Bella.";
      system("pause >nul");

      cout << "\n\n        Jack goes into the van, grabs the s'mores stuff, and returns.";
      system("pause >nul");

      // If the alcohol is still at the campsite, Connor will mention it,
      // but his survival instinct will stop him from going to grab it.
      if (alcohol == 1)
      {
         cout << "\n\nSARAH:  Do you guys want to grab the beer?";
         system("pause >nul");

         cout << "\n\nCONNOR: Man, you know what... Jack had a good point earlier.\n        We should stay sober.  We don't know what's out there.";
         system("pause >nul");

         cout << "\n\nSARAH:  I agree.";
         system("pause >nul");
      }

      cout << "\n\n        Casey, Jack, and Bella return to the campsite.";
      system("pause >nul");

      // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
      cout << "\n\n        { CLEARING SCREEN... }";
      system("pause >nul");
      system("cls");
      cout << "Controlling: Jack\n";

      cout << "\n\nJACK:   Hey, nice to see the campfire's still going.";
      system("pause >nul");

      cout << "\n\n        Connor, Jack, and Sarah begin to roast marshmallows.";
      system("pause >nul");

      cout << "\n\nCONNOR: Hey, these metal sticks you got work pretty good!";
      system("pause >nul");

      cout << "\n\nJACK:   Yeah, my mom always gets these ones.  They work great!";
      system("pause >nul");

      cout << "\n\nSARAH:  You know, I haven't gotten the chance to know you boys yet.";
      system("pause >nul");

      cout << "\n\nCONNOR: I haven't gotten the chance to know you yet either.";
      system("pause >nul");

      cout << "\n\n1. QUESTIONING: What about me?";               // Option 1
      cout <<   "\n2. CONSIDERATE: It's a good time for that..."; // Option 2

      do
      {
         cout << "\n\nChoice: ";
         cin  >> choice;
      } while (choice != '1' && choice != '2');

      // This choice slightly lowers Jack and Connor's relationship.
      if (choice == '1')
      {
         cout << "\n\nJACK:   Hey Connor, she doesn't know me well yet either.";
         cout << "\n\n        *Connor didn't like that.*";
         rJackConnor -= 1;
         system("pause >nul");

         cout << "\n\nCONNOR: Well, I meant both of us, not just me.";
         system("pause >nul");
      }

      // This choice slightly raises Jack and Sarah's relationship.
      else if (choice == '2')
      {
         cout << "\n\nJACK:   Well, now is a good time for introductions!";
         rJackSarah += 1;
         system("pause >nul");

         cout << "\n\nCONNOR: Sure is!";
         system("pause >nul");
      }

      // The screen is cleared, and the character that the player controls switches to Connor.
      cout << "\n\n        [Switching characters...]";
      cout << "\n\n        { CLEARING SCREEN... }";
      system("pause >nul");
      system("cls");
      cout << "Controlling: Connor\n";

      cout << "\n\nSARAH:  You guys probably notice I act all cool and needy all the time.\n        It just... makes me feel better.  My home life is pretty tough.";
      system("pause >nul");

      cout << "\n\nSARAH:  My mom is well... a drug addict, and she was recently admitted to a mental hospital.\n        My dad tries to do it all by himself, but there are always those awful days, you know.";
      system("pause >nul");

      cout << "\n\n1. SYMPATHETIC: Must be tough.";                        // Choice 1
      cout <<   "\n2. JUDGEMENTAL: Neediness wouldn't please your dad..."; // Choice 2
      
      do
      {
         cout << "\n\nChoice: ";
         cin  >> choice;
      } while (choice != '1' && choice != '2');

      // This choice significantly raises Connor and Sarah's relationship.
      if (choice == '1')
      {
         cout << "\n\nCONNOR: That must be tough, dude...";
         rConnorSarah += 2;
         system("pause >nul");

         cout << "\n\nJACK:   Yeah, for real.";
         system("pause >nul");

         cout << "\n\nSARAH:  And well, as for the reason I act the way I do...";
         system("pause >nul");
      }

      // This choice significantly lowers Connor and Sarah's relationship.
      else if (choice == '2')
      {
         cout << "\n\nCONNOR: You know, your cool, needy behavior wouldn't please your dad.";
         cout << "\n\n        *Sarah didn't like that.*";
         rConnorSarah -= 2;
         system("pause >nul");

         cout << "\n\nSARAH:  Yeah, but there's a reason why I act like that.";
         system("pause >nul");
      }

      cout << "\n\nSARAH:  When I'm at home, I have to cook, do laundry, and clean all by myself.\n        Since my dad works so much to support us, basically nothing is done for me.";
      system("pause >nul");

      cout << "\n\nSARAH:  So you know, since I can't act needy at home, it makes me feel better\n        to act that way around my friends.";
      system("pause >nul");

      cout << "\n\n1. UNDERSTANDING: Makes sense....";              // Choice 1
      cout <<   "\n2. APPRECIATIVE:  Glad you're being genuine..."; // Choice 2

      do
      {
         cout << "\n\nChoice: ";
         cin  >> choice;
      } while (choice != '1' && choice != '2');

      // This choice is neutral, and doesn't affect the final outcome of the story.
      if (choice == '1')
      {
         cout << "\n\nCONNOR: Yeah, I understand.";
         system("pause >nul");

         cout << "\n\nSARAH:  Thanks.";
         system("pause >nul");
      }

      // This choice significantly raises Connor and Sarah's relationship.
      else if (choice == '2')
      {
         cout << "\n\nCONNOR: I'm glad you're opening up, Sarah.";
         rConnorSarah += 2;
         system("pause >nul");

         cout << "\n\nSARAH:  Honestly, it feels relieving to finally open up to someone.";
         system("pause >nul");
      }

      cout << "\n\n        Jack, Connor, and Sarah return to casual conversation around the campfire,\n         waiting for Casey and Bella to return.";
      system("pause >nul");
   }

   // Let the player know that chapter 3 scene 1 is complete, and
   // clear the screen, making way for a new scene.
   cout << "\n\n        [Scene Complete.]";
   system("pause >nul");

   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");

   /*-------------------------------------------------*/
   /*               Chapter 3, Scene 2                */
   /*-------------------------------------------------*/
   
   // Info screen for Chapter 3, Scene 2
   cout << "Chapter 3, Scene 2";
   cout << "\n\nCharacters:";
   cout <<   "\nCasey, Bella";
   cout << "\n\nLocation: In the woods\n\n";
   system("pause");
   system("cls");

   // The player will make decisions for Casey.
   cout << "Controlling: Casey\n";

   cout << "\n\nBELLA:  We've been traveling for a while out here.  It is quite peaceful though, isn't it?";
   system("pause >nul");

   cout << "\n\n1. SPOOKED:     Unsettling..."; // Choice 1
   cout <<   "\n2. COMFORTABLE: Yeah.";         // Choice 2

   do
   {
      cout << "\n\nChoice: ";
      cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice is neutral, and doesn't affect the final outcome of the story.
   if (choice == '1')
   {
      cout << "\n\nCASEY:  It's a little unsettling, honestly, knowing what happened here.";
      system("pause >nul");

      cout << "\n\nBELLA:  Yeah, true...";
      system("pause >nul");
   }

   // This choice slightly raises Casey and Bella's relationship.
   else if (choice == '2')
   {
      cout << "\n\nCASEY:  Yeah, it's nice.";
      rCaseyBella += 1;
      system("pause >nul");
   }

   cout << "\n\nBELLA:  We should probably head back soon.  We've gone far enough, and we don't want to get lost.";
   system("pause >nul");

   cout << "\n\nCASEY:  You're right.";
   system("pause >nul");

   // If James is dead, Casey and Bella will find his corpse.
   // No matter what, Casey will be attacked by a zombie during this scene.
   if (JamesAlive == 0)
   {
      cout << "\n\n        ...";
      system("pause >nul");

      cout << "\n\n        1 minute later...";
      system("pause >nul");

      cout << "\n\n        As Casey and Bella move along, they find a freshly killed body, with its head torn off.";
      system("pause >nul");

      cout << "\n\nBELLA:  AHHH!  Oh my friggin gosh, dude!";
      system("pause >nul");

      cout << "\n\nCASEY:  Oh no, oh no... I wonder how this happened...";
      system("pause >nul");

      cout << "\n\nCASEY:  I think we should head back before we meet a similar fate.";
      system("pause >nul");

      cout << "\n\nBELLA:  Yeah...";
      system("pause >nul");

      cout << "\n\n        Suddenly, Casey and Bella hear the sound of running coming from behind a pile of bushes.";
      system("pause >nul");

      cout << "\n\n        Before they have time to react, a zombie pops out and charges Casey.";
      system("pause >nul");
   }
   else
   {
      cout << "\n\n        ...";
      system("pause >nul");

      cout << "\n\n        2 minutes later...";
      system("pause >nul");

      cout << "\n\n        Suddenly, Casey and Bella hear the sound of running coming from behind a pile of bushes.";
      system("pause >nul");

      cout << "\n\nBELLA:  What was that?";
      system("pause >nul");

      cout << "\n\n        Before they have time to react, a zombie pops out and charges Casey.";
      system("pause >nul");
   }

   /* ! ! ! ! Q U I C K   T I M E   E V E N T ! ! ! ! */
   cout << "\n\n        TYPE \"STAB\":   ";
   now = clock();
   cin >> message;

   // Passing or failing this particular quick time event has no consequences.
   if ((message == "STAB" || message == "stab") && ((clock() - now) < qte_time))
   {
      cout << "\n\n        Casey pulls out his pocket knife and stabs the zombie.";
      system("pause >nul");

      cout << "\n\n        The zombie screeches in pain, and pulls the knife back out.\n        It then throws the knife far away.";
      system("pause >nul");

      cout << "\n\n        Seemingly unfazed, the zombie grabs a hold of one of Casey's arms, and using its inhuman strength, starts dragging him away.";
      system("pause >nul");
   }
   else
   {
      cout << "\n\n        Casey fails to reach for his pocket knife.\n        The zombie grabs it out of his pocket and throws it far away.";
      system("pause >nul");

      cout << "\n\n        The zombie grabs a hold of one of Casey's arms, and using its inhuman strength, starts dragging him away.";
      system("pause >nul");
   }

   // The screen is cleared, and the character that the player controls switches to Bella.
   cout << "\n\n        [Switching characters...]";
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   cout << "Controlling: Bella\n";

   cout << "\n\nBELLA:  NO!  Casey!!";
   system("pause >nul");

   cout << "\n\n        Bella begins chasing after Casey, although the zombie is difficult to keep pace with.";
   system("pause >nul");

   cout << "\n\n        A low-hanging log is up ahead.";
   system("pause >nul");


   // Three quick time events happen here.  If at least two of the three of these quick time events are passed, Casey
   // will survive.  Otherwise, Casey will die.  The number of passed QTE's are tracked in the chaseProgress variable.

   /* ! ! ! ! Q U I C K   T I M E   E V E N T ! ! ! ! */
   cout << "\n\n        TYPE \"DUCK\":   ";
   now = clock();
   cin >> message;

   if ((message == "DUCK" || message == "duck") && ((clock() - now) < qte_time))
   {
      cout << "\n\n        Bella ducks underneath the log.";
      chaseProgress += 1;
      system("pause >nul");
   }
   else
   {
      cout << "\n\n        Bella hits the log.";
      system("pause >nul");
   }

   cout << "\n\n        A stump on the ground approaches.";
   system("pause >nul");

   /* ! ! ! ! Q U I C K   T I M E   E V E N T ! ! ! ! */
   cout << "\n\n        TYPE \"JUMP\":   ";
   now = clock();
   cin >> message;

   if ((message == "JUMP" || message == "jump") && ((clock() - now) < qte_time))
   {
      cout << "\n\n        Bella jumps over the stump.";
      chaseProgress += 1;
      system("pause >nul");
   }
   else
   {
      cout << "\n\n        Bella trips on the stump.";
      system("pause >nul");
   }

   cout << "\n\n        A rock is in front of you, slightly to the right.";
   system("pause >nul");

   /* ! ! ! ! Q U I C K   T I M E   E V E N T ! ! ! ! */
   cout << "\n\n        TYPE \"LEAN\":   ";
   now = clock();
   cin >> message;

   if ((message == "LEAN" || message == "lean") && ((clock() - now) < qte_time))
   {
      cout << "\n\n        Bella leans to the left to avoid the rock.";
      chaseProgress += 1;
      system("pause >nul");
   }
   else
   {
      cout << "\n\n        Bella hits the rock.";
      system("pause >nul");
   }

   // If two of three quick time events are passed, Casey survives,
   // and Casey and Bella's relationship is raised drastically.
   if (chaseProgress >= 2)
   {
      rCaseyBella += 3;

      cout << "\n\n        The zombie stops at a certain spot, and grabs a handle, revealing a near-perfectly hidden trapdoor.";
      system("pause >nul");

      cout << "\n\n        As the zombie is mostly inside, Bella catches up, and pulls out her taser.";
      system("pause >nul");

      cout << "\n\n        Bella tases the zombie's hand, causing the zombie to fall into the trapdoor and let go of Casey, who had not been fully inside yet.";
      system("pause >nul");

      cout << "\n\n        BELLA:  You alright?";
      system("pause >nul");

      cout << "\n\n        CASEY:  You just saved my life, Bella...  close one there, and that would've been one horrible way to go.";
      system("pause >nul");

      cout << "\n\n        Casey and Bella hurry back to the campsite.";
      system("pause >nul");
   }

   // If zero or one of three quick time events are passed, Casey dies.
   else
   {
      CaseyAlive = 0;

      cout << "\n\n        The zombie stops at a certain spot, and grabs a handle, revealing a near-perfectly hidden trapdoor.";
      system("pause >nul");

      cout << "\n\n        Bella does not quite catch up on time, and the zombie drags Casey into the trapdoor.";
      system("pause >nul");

      cout << "\n\n        Bella yanks at the handle, only to find that the trapdoor is locked.\n        As she tries to no avail to yank it open, she can hear the sound of screaming inside, and realizes that it is too late.";
      system("pause >nul");

      cout << "\n\n        [Casey died.]";
      system("pause >nul");

      cout << "\n\n        Frantically, Bella makes her way back to the campsite.";
      system("pause >nul");
   }

   // Let the player know that chapter 3 scene 2 is complete, and
   // clear the screen, making way for a new scene.
   cout << "\n\n        [Scene Complete.]";
   cout << "\n\n        [Chapter 3 Complete.]";
   system("pause >nul");

   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   
   /*-------------------------------------------------*/
   /*               Chapter 4, Scene 1                */
   /*-------------------------------------------------*/

   // Info screen for Chapter 4, Scene 1
   cout << "Chapter 4, Scene 1";
   cout << "\n\nCharacters:";
   cout <<   "\nJack, Bella, Sarah (if alive), Casey (if alive), Connor (if alive)";
   cout << "\n\nLocation: At the campfire\n\n";
   system("pause");
   system("cls");

   // The player will make decisions for Jack.
   cout << "Controlling: Jack\n";

   cout << "\n\n        10 minutes later, at the campfire...";
   system("pause >nul");

   // Sarah will speak up if she is alive.
   if (SarahAlive == 1)
   {
      cout << "\n\nSARAH:  Mmm... these marshmallows are good.  What kind did you get?";
      system("pause >nul");

      cout << "\n\nJACK:   (whispering) Shh!  I think I just heard something behind us...";
      system("pause >nul");

      cout << "\n\n        Jack turns around and points his pistol at the woods.";
      system("pause >nul");
   }
   else
   {
      cout << "\n\n        Jack hears a noise from behind him.";
      system("pause >nul");

      cout << "\n\n        Jack turns around and points his pistol at the woods.";
      system("pause >nul");
   }

   cout << "\n\n1. SHOOT"; // Option 1
   cout <<   "\n2. WAIT";  // Option 2

   do
   {
      cout << "\n\nChoice: ";
      cin  >> choice;
   } while (choice != '1' && choice != '2');

   // If the player shoots, they will hit Casey (if he is alive.)  This will weaken
   // him during the final fight.
   if (choice == '1')
   {
      if (CaseyAlive == 1)
      {
         cout << "\n\n        Jack shoots at the noise.";
         system("pause >nul");

         cout << "\n\n        Suddenly, he hears a cry of agony.  It sounds like... Casey.";
         system("pause >nul");

         cout << "\n\nCASEY:  It only hit the edge of my shoulder, I'll be fine...";
         system("pause >nul");

         cout << "\n\nJACK:   I'm so sorry, Casey!.";
         system("pause >nul");

         CaseyInjured = 1;
      }
      else
      {
         cout << "\n\n        Jack shoots at the noise, but his shot does not hit anything.";
         system("pause >nul");

         cout << "\n\nBELLA:  It's just me!  Don't shoot!";
         system("pause >nul");
      }
   }

   else if (choice == '2')
   {
      if (CaseyAlive == 1)
      {
         cout << "\n\n        Jack hesitates.";
         system("pause >nul");

         cout << "\n\nBELLA:  It's just us!  Don't shoot!";
         system("pause >nul");
      }
      else
      {
         cout << "\n\n        Jack hesitates.";
         system("pause >nul");

         cout << "\n\nBELLA:  It's just me!  Don't shoot!";
         system("pause >nul");
      }
   }

   // If Casey is alive, Bella will describe how they got chased by the zombie.
   // Casey will occasionally chime in.
   if (CaseyAlive == 1)
   {
      cout << "\n\n        Casey and Bella step into sight, and return to the campfire.";
      system("pause >nul");

      cout << "\n\nBELLA:  I think me and Casey just had the most terrifying experience of our lives.";
      system("pause >nul");

      cout << "\n\nBELLA:  So me and Casey were out walking, and out of nowhere,\n        this zombie-like creature appeared, grabbed Casey, and started dragging him away.";
      system("pause >nul");

      cout << "\n\nCASEY:  Don't get me wrong, I tried my hardest to resist, but this thing had like... inhuman strength.";
      system("pause >nul");

      // Connor will also speak up if he is alive.
      if (ConnorAlive == 1)
      {
         cout << "\n\nCONNOR: Hol up dude... are you sure you saw a... zombie?  Those are real?";
         system("pause >nul");

         cout << "\n\nCASEY:  Well, it definitely looked like one.";
         system("pause >nul");

         cout << "\n\nBELLA:  What he said.";
         system("pause >nul");
      }

      cout << "\n\nBELLA:  I chased after it, and eventually, it stopped at some random spot.\n        It then bent down and opened a trapdoor that was almost perfectly hidden.";
      system("pause >nul");

      cout << "\n\nBELLA:  Just before it dragged Casey in, I caught up, pulled out my taser,\n        and sent that thing back where it came from.";
      system("pause >nul");

      cout << "\n\nJACK:   Wild...";
      system("pause >nul");
   }

   // If Casey is dead, Bella will describe how Casey got dragged away by the zombie and killed.
   else
   {
      cout << "\n\n        Bella steps into sight, and returns to the campfire.";
      system("pause >nul");

      cout << "\n\nJACK:   Oh no... you look rough.  Hey, where's Casey?";
      system("pause >nul");

      cout << "\n\nBELLA:  He's... dead.";
      system("pause >nul");

      // Connor will answer Bella's question if he is alive.
      // Otherwise, Jack will answer the question.
      if (ConnorAlive == 1)
      {
         cout << "\n\nCONNOR: Oh man, that's awful!  What happened?";
         system("pause >nul");
      }
      else
      {
         cout << "\n\nJACK:   ...";
         system("pause >nul");

         cout << "\n\nJACK:   What happened?";
         system("pause >nul");
      }

      cout << "\n\nBELLA:  You wouldn't believe me if I told you.";
      system("pause >nul");

      // Sarah will reply to Bella if Connor is alive.
      // Otherwise, Jack will reply instead.
      if (ConnorAlive == 1)
      {
         cout << "\n\nSARAH:  Is it really that bad?";
         system("pause >nul");
      }
      else if (SarahAlive == 1)
      {
         cout << "\n\nJACK:   Trust me, we would.";
         system("pause >nul");
      }
      else
      {
         cout << "\n\nJACK:   Trust me, I would.";
         system("pause >nul");
      }

      cout << "\n\nBELLA:  So me and Casey were out walking, and out of nowhere,\n        this zombie-like creature appeared, grabbed Casey, and started dragging him away.";
      system("pause >nul");

      cout << "\n\nBELLA:  I chased after it, and eventually, it stopped at some random spot.\n        It then bent down and opened a trapdoor that was almost perfectly hidden.";
      system("pause >nul");

      cout << "\n\nBELLA:  I was too late, though... I couldn't get there in time.  That creature\n        dragged Casey into its cave, locked the trapdoor, and killed him.";
      system("pause >nul");

      // Sarah will speak up if she is alive.
      if (SarahAlive == 1)
      {
         cout << "\n\nSARAH:  This is messed up...";
         system("pause >nul");
      }

      cout << "\n\nBELLA:  I could hear him screaming in agony, but I couldn't reach him.";
      system("pause >nul");

      // If Connor is alive (meaning that Sarah is also alive,) then the two of them will speak up here.
      if (ConnorAlive == 1)
      {
         cout << "\n\nCONNOR: That's really horrible, but man... are you sure you saw a... zombie?";
         system("pause >nul");

         cout << "\n\nSARAH:  It definitely wasn't human...";
         system("pause >nul");
      }

      cout << "\n\nJACK:   Wild...";
      system("pause >nul");
   }

   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   cout << "Controlling: Jack\n";

   // If Connor and Sarah are both dead, Jack will describe to Bella what happened.
   if (SarahAlive == 0)
   {
      cout << "\n\nBELLA:  Where's Sarah and Connor?";
      system("pause >nul");

      cout << "\n\nJACK:   That zombie-like creature you described... Connor transformed into one of them.";
      system("pause >nul");

      cout << "\n\nJACK:   He then ran over to Sarah and choked her to death.\n        I had to shoot him, but by then, it was too late.";
      system("pause >nul");

      cout << "\n\nBELLA:  This night is so horribly messed up... we need a way out of here.";
      system("pause >nul");

      cout << "\n\nBELLA:  Wait, where'd you get that pistol?";
      system("pause >nul");

      cout << "\n\nJACK:   It's Connor's dad's.  Connor brought it for protection.";
      system("pause >nul");

      cout << "\n\nBELLA:  You know, he never would've guessed it would be needed against himself.";
      system("pause >nul");

      cout << "\n\nJACK:   Yeah, it's devastating...";
      system("pause >nul");

      // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
      cout << "\n\n        { CLEARING SCREEN... }";
      system("pause >nul");
      system("cls");
      cout << "Controlling: Jack\n";
   }

   // If Connor is dead (but not Sarah,) Jack will describe to Bella what happened.
   else if (ConnorAlive == 0)
   {
      cout << "\n\nBELLA:  Where's Connor?";
      system("pause >nul");

      cout << "\n\nJACK:   That zombie-like creature you described... Connor transformed into one of them.";
      system("pause >nul");

      cout << "\n\nSARAH:  After that, he ran over to me and started choking me!\n        Jack had to shoot Connor, which saved my life.";
      system("pause >nul");

      cout << "\n\nJACK:   It... wasn't what I would've liked to do.  I did what I had to.";
      system("pause >nul");

      cout << "\n\nBELLA:  This night is so horribly messed up... we need a way out of here.";
      system("pause >nul");

      cout << "\n\nBELLA:  Wait, Jack, where'd you get that pistol?";
      system("pause >nul");

      cout << "\n\nJACK:   It's Connor's dad's.  Connor brought it for protection.";
      system("pause >nul");

      cout << "\n\nBELLA:  You know, he never would've guessed it would be needed against himself.";
      system("pause >nul");

      cout << "\n\nJACK:   Yeah, it's devastating...";
      system("pause >nul");

      // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
      cout << "\n\n        { CLEARING SCREEN... }";
      system("pause >nul");
      system("cls");
      cout << "Controlling: Jack\n";
   }
   // If Connor is still alive, he will exchange a brief word with Bella.
   else
   {
      cout << "\n\nBELLA:  Hey Jack, I just noticed you had that pistol.";
      system("pause >nul");

      cout << "\n\nCONNOR: I actually brought it, man.  It's my dad's but I'm \'borrowing\' it.";
      system("pause >nul");

      cout << "\n\nBELLA:  Nice, dude...";
      system("pause >nul");
   }

   cout << "\n\nBELLA:  You know... I noticed something while I was out there.  These \'zombies\' aren't really zombies.";
   system("pause >nul");

   // Sarah will speak up if she is still alive.
   if (SarahAlive == 1)
   {
         cout << "\n\nSARAH:  What do you mean by that?";
         system("pause >nul");
   }

   cout << "\n\nBELLA:  Well, the zombie was able to set up a very well-disguised trapdoor.";
   system("pause >nul");

   cout << "\n\nBELLA:  Regular old dumb zombies couldn't do that.\n        It's almost as if these zombies retain human intelligence.";
   system("pause >nul");

   // Connor will reply to Bella if he is still alive.
   // Otherwise, Jack will reply instead.
   if (ConnorAlive == 1)
   {
      cout << "\n\nCONNOR: You got a point, man...";
      system("pause >nul");
   }
   else
   {
      cout << "\n\nJACK:   Yeah, true...";
      system("pause >nul");
   }

   // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   cout << "Controlling: Jack\n";

   cout << "\n\nJACK:   I'm still confused on how this place was opened for a few days before an attack happened.";
   system("pause >nul");

   // Casey will speak up if he is still alive.
   // Otherwise, Bella will speak up.
   if (CaseyAlive == 1)
   {
      cout << "\n\nCASEY:  I got attacked pretty far from the campsite, so my guess is that the\n        zombies are highly territorial, and attack those who get tho close to their home.";
      system("pause >nul");
   }
   else
   {
      cout << "\n\nBELLA:  Casey got attacked pretty far from the campsite, so my guess is that the\n        zombies are highly territorial, and attack those who get tho close to their home.";
      system("pause >nul");
   }

   // If Connor is dead, Jack will connect the zombies with what happened to Connor.
   if (ConnorAlive == 0)
   {
      cout << "\n\nJACK:   The attack could've also happened through infection though, as I saw with Connor.";
      system("pause >nul");

      cout << "\n\nBELLA:  Did Connor do anything unique before his infection that could've caused it?";
      system("pause >nul");

      // If Sarah is alive, she will reply to Bella.
      // Otherwise, Jack will reply to Bella.
      if (SarahAlive == 1)
      {
         cout << "\n\nSARAH:  He had a whole bunch of beer.";
         system("pause >nul");
      }
      else
      {
         cout << "\n\nJACK:   Yeah, he had quite a lot of beer.";
         system("pause >nul");
      }

      // If Casey is alive, he will reply to Sarah/Jack.
      // Otherwise, Bella will reply to Sarah/Jack.
      if (CaseyAlive == 1)
      {
         cout << "\n\nCASEY:  I had a sip of beer right after we pulled in though, and I'm fine.";
         system("pause >nul");
      }
      else
      {
         cout << "\n\nBELLA:  Casey had a sip of beer right after we pulled in though, and he was fine.";
         system("pause >nul");
      }

      cout << "\n\nJACK:   Maybe Connor got too drunk?  I'm really not sure.";
      system("pause >nul");
   }

   // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   cout << "Controlling: Jack\n";

   cout << "\n\n        The sound of footsteps once again can be heard from behind the bushes.";
   system("pause >nul");

   cout << "\n\n1. SHOOT"; // Choice 1
   cout <<   "\n2. WAIT";  // Choice 2

   do
   {
      cout << "\n\nChoice: ";
      cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice is neutral, and doesn't affect the final outcome of the story.
   if (choice == '1')
   {
      cout << "\n\n        Jack shoots at the noise.  The shot doesn't seem to hit anything.";
      system("pause >nul");
   }

   // This choice is neutral, and doesn't affect the final outcome of the story.
   else if (choice == '2')
   {
      cout << "\n\n        Jack hesitates.";
      system("pause >nul");
   }

   cout << "\n\n        An unfamiliar man steps into sight.\n        (At least, unfamiliar to those around the campfire...)";
   system("pause >nul");

   cout << "\n\nTHOMAS: Hey, the name's Thomas.  I heard some ruckus down here, and came to see if everyone's okay.";
   system("pause >nul");

   cout << "\n\n1. DISMISSIVE: We're fine";      // Choice 1
   cout <<   "\n2. HONEST:     Not really okay"; // Choice 2

   do
   {
      cout << "\n\nChoice: ";
      cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice is neutral, and doesn't affect the final outcome of the story.
   if (choice == '1')
   {
      cout << "\n\nJACK:   We're fine, I guess...";
      system("pause >nul");
   }

   // This choice is neutral, and doesn't affect the final outcome of the story.
   else if (choice == '2')
   {
      cout << "\n\nJACK:   \"Okay\" is one way to put it...";
      system("pause >nul");
   }

   cout << "\n\nTHOMAS: This place is not safe, you guys.  You all really need to head out.";
   system("pause >nul");

   cout << "\n\nBELLA:  We know.  I just saw this zombie-looking thing earlier.  Have you been attacked too?";
   system("pause >nul");

   cout << "\n\nTHOMAS: Last night, yeah.  You know, after that attack, I really got to\n        thinking, and I believe I have an explanation for all of this.";
   system("pause >nul");

   // Let the player know that chapter 1 scene 1 is complete, and
   // clear the screen, making way for a new scene.
   cout << "\n\n        [Scene Complete.]";
   system("pause >nul");

   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   
   /*-------------------------------------------------*/
   /*               Chapter 4, Scene 2                */
   /*-------------------------------------------------*/

   // Info screen for Chapter 4, Scene 2
   cout << "Chapter 4, Scene 2 (Thomas's Flashback)";
   cout << "\n\nCharacters:";
   cout <<   "\nThomas";
   cout << "\n\nLocation: At a mental hospital, 10 years ago\n\n";
   system("pause");
   system("cls");

   // The player will make decisions for Thomas.
   cout << "Controlling: Thomas\n";

   cout << "\n\nWORKER: Hey Thomas, we got a new patient coming in today.\n        This isn't any normal patient, though.";
   system("pause >nul");

   cout << "\n\n1. CONFUSED: Not normal?";      // Choice 1
   cout <<   "\n2. SCARED:   Can't be good..."; // Choice 2

   do
   {
      cout << "\n\nChoice: ";
      cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice is neutral, and doesn't affect the final outcome of the story. 
   if (choice == '1')
   {
      cout << "\n\nTHOMAS: What do you mean by \"not normal\"?";
      system("pause >nul");
   }

   // This choice is neutral, and doesn't affect the final outcome of the story.
   else if (choice == '2')
   {
      cout << "\n\nTHOMAS: That can't be good.";
      system("pause >nul");

      cout << "\n\nWORKER: Sure isn't.";
      system("pause >nul");
   }

   cout << "\n\nWORKER: Every place she gets moved to Suddenly has a bunch of unexplained patient deaths.";
   system("pause >nul");

   cout << "\n\nWORKER: She claims it is because she can control demons, apparently.";
   system("pause >nul");

   cout << "\n\n1. THOUGHTFUL: She's the devil?"; // Choice 1
   cout <<   "\n2. RATIONAL:   Impossible!";      // Choice 2

   do
   {
      cout << "\n\nChoice: ";
      cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice is neutral, and doesn't affect the final outcome of the story.
   if (choice == '1')
   {
      cout << "\n\nTHOMAS: Well, if she could control demons, would that make her the devil?";
      system("pause >nul");

      cout << "\n\nWORKER: You are probably overthinking it.  I highly doubt her claims are really true.";
      system("pause >nul");
   }

   // This choice is neutral, and doesn't affect the final outcome of the story.
   else if (choice == '2')
   {
      cout << "\n\nTHOMAS: But... that's impossible!";
      system("pause >nul");

      cout << "\n\nWORKER: My thoughts exactly.";
      system("pause >nul");
   }

   cout << "\n\nWORKER: I'll escort you to her room.  Her cell is blocked off, so she can't get to you.";
   system("pause >nul");

   cout << "\n\n1. QUESTION: Who is she?";              // Choice 1
   cout <<   "\n2. QUESTION: Where did she come from?"; // Choice 2

   do
   {
      cout << "\n\nChoice: ";
      cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice is neutral, and doesn't affect the final outcome of the story.
   if (choice == '1')
   {
      cout << "\n\nTHOMAS: Who even is this lady, anyway?";
      system("pause >nul");

      cout << "\n\nWORKER: I don't know who she is, but I do know how she was first put in a mental hospital...";
      system("pause >nul");
   }

   // This choice is neutral, and doesn't affect the final outcome of the story.
   else if (choice == '2')
   {
      cout << "\n\nTHOMAS: Where did this lady even come from?";
      system("pause >nul");

      cout << "\n\nWORKER: Okay, let's start from the beginning...";
      system("pause >nul");
   }

   // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   cout << "Controlling: Thomas\n";

   cout << "\n\nWORKER: One night, the police got a frantic phone call from a young boy,\n        saying that his sister had killed both of their parents.";
   system("pause >nul");

   cout << "\n\nWORKER: The police arrived to the girl sobbing over the body of her father,\n        whose head was severed from his body.";
   system("pause >nul");

   cout << "\n\nWORKER: Upon questioning, it was found out that her father was an alcoholic, and abused her.";
   system("pause >nul");

   cout << "\n\nWORKER: One notable thing she said was: \"I didn't kill him.  I made them do it.\"";
   system("pause >nul");

   cout << "\n\n1. LOGICAL:   Demons?";          // Choice 1
   cout <<   "\n2. DISBELIEF: She killed them."; // Choice 2

   do
   {
      cout << "\n\nChoice: ";
      cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice is neutral, and doesn't affect the final outcome of the story.
   if (choice == '1')
   {
      cout << "\n\nTHOMAS: Maybe she made demons kill him.\n        She does claim to control demons, after all.";
      system("pause >nul");

      cout << "\n\nWORKER: Hmm... maybe.";
      system("pause >nul");
   }

   // This choice is neutral, and doesn't affect the final outcome of the story.
   else if (choice == '2')
   {
      cout << "\n\nTHOMAS: She was probably just bluffing.\n        She killed her parents in cold blood.";
      system("pause >nul");

      cout << "\n\nWORKER: That's the most likely thing, I think.";
      system("pause >nul");
   }

   cout << "\n\nWORKER: Here's her cell, right here.  Make sure to stay safely behind the bars.";
   system("pause >nul");

   cout << "\n\n        The woman slowly turns to face Thomas.  Her expression is deceptively calm, yet Thomas can sense the evil in her eyes.";
   system("pause >nul");

   cout << "\n\nTHOMAS: ...";
   system("pause >nul");

   cout << "\n\nTHOMAS: Hello...";
   system("pause >nul");

   cout << "\n\n???:    So I assume you're my new caretaker?";
   system("pause >nul");

   cout << "\n\nTHOMAS: Yeah... what's your name?";
   system("pause >nul");

   cout << "\n\nJOSIE:  I'm Josie.";
   system("pause >nul");

   // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   cout << "Controlling: Thomas\n";

   cout << "\n\n        [The flashback moves forward in time.]";
   system("pause >nul");

   cout << "\n\n        3 weeks later...";
   system("pause >nul");

   cout << "\n\n        Thomas enters the cell once again for a chat with Josie.";
   system("pause >nul");

   cout << "\n\nJOSIE:  Hello, once again...";
   system("pause >nul");

   cout << "\n\nJOSIE:  You know, Thomas, this place isn't better than any of the rest of them.";
   system("pause >nul");

   cout << "\n\nJOSIE:  You're really the only one in here I can trust, so can you keep this information secret?";
   system("pause >nul");

   cout << "\n\nTHOMAS: Okay.";
   system("pause >nul");

   cout << "\n\nJOSIE:  I'm so tired of these alcoholics ruining my life, so I'm going to stop that.\n        I'm going to release a demon that curses anyone on this property who drinks alchohol.";
   system("pause >nul");

   cout << "\n\nTHOMAS: You... what?";
   system("pause >nul");

   cout << "\n\nJOSIE:  But I do have my limitations.  I can't curse anyone who isn't doing something wrong, and I can't curse anyone under 18.";
   system("pause >nul");

   cout << "\n\nTHOMAS: Okay, okay...";
   system("pause >nul");

   cout << "\n\nTHOMAS: Alcohol is only illegal if you're under 21, so doesn't that mean your curse...";
   system("pause >nul");

   cout << "\n\nJOSIE:  Will only affect alcohol drinkers between the ages of 18 and 20.";
   system("pause >nul");

   cout << "\n\nTHOMAS: Okay, if you really think that's going to help anything.\n        So... what will this \'curse\' do?";
   system("pause >nul");

   cout << "\n\nJOSIE:  It will cause the demon to take control of the person, causing the person to attack anyone they care about within this vicinity.";
   system("pause >nul");

   cout << "\n\nJOSIE:  They will then be trapped within a certain radius of this mental hospital, and never be able to leave.";
   system("pause >nul");

   cout << "\n\nTHOMAS: And... would there perhaps be a way to end this curse?";
   system("pause >nul");

   cout << "\n\nJOSIE:  There's only one way... you would have to... kill me.";
   system("pause >nul");

   // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   cout << "Controlling: Thomas\n";

   cout << "\n\n        [The flashback moves forward in time.]";
   system("pause >nul");

   cout << "\n\n        1 day later...";
   system("pause >nul");

   cout << "\n\n        It's a new day, and Thomas reenters the cell.";
   system("pause >nul");

   cout << "\n\nJOSIE:  ...";
   system("pause >nul");

   cout << "\n\nTHOMAS: Did you execute that curse that you were talking about?";
   system("pause >nul");

   cout << "\n\nJOSIE:  Never mind that! I'm going to burn this place to the ground!";
   system("pause >nul");

   cout << "\n\nTHOMAS: Woah, what's got you upset?";
   system("pause >nul");

   cout << "\n\nJOSIE:  One of the abusive guards was taking alcohol again!";
   system("pause >nul");

   cout << "\n\nTHOMAS: Please don't do harm to this place, there are so many innocent people!";
   system("pause >nul");

   cout << "\n\nJOSIE:  No there aren't!  You're the only decent one here!";
   system("pause >nul");

   // Let the player know that chapter 4 scene 2 is complete, and
   // clear the screen, making way for a new scene.
   cout << "\n\n        [Flashback ended.]";
   cout << "\n\n        [Scene Complete.]";
   system("pause >nul");

   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");

   /*-------------------------------------------------*/
   /*               Chapter 4, Scene 3                */
   /*-------------------------------------------------*/

   cout << "Chapter 4, Scene 3";
   cout << "\n\nCharacters:";
   cout <<   "\nThomas, Jack, Bella, Casey (if alive), Connor (if alive), Sarah (if alive)";
   cout << "\n\nLocation: Around the campfire (once again)\n\n";
   system("pause");
   system("cls");

   // The player will make decisions for Sarah if she is alive.
   // Otherwise, the player will make decisions for Jack.
   if (SarahAlive == 1)
   {
      cout << "Controlling: Sarah\n";
   }
   else
   {
      cout << "Controlling: Jack\n";
   }

   cout << "\n\nTHOMAS: And the next day, I returned to work, only to find the whole facility up in flames.";
   system("pause >nul");

   cout << "\n\nTHOMAS: I took her seriously when she said she'd burn down the mental hospital,\n        but I forgot all of that stuff that she said about the curse.";
   system("pause >nul");

   cout << "\n\n1. UNDERSTANDING: It's been 10 years..."; // Option 1
   cout <<   "\n2. CONFUSED:      How did you forget?";   // Option 2

   do
   {
      cout << "\n\nChoice: ";
      cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice is neutral, and doesn't affect the final outcome of the story. 
   if (choice == '1')
   {
      if (SarahAlive == 1)
      {
         cout << "\n\nSARAH:  I understand.  It's been 10 years, after all.";
         system("pause >nul");
      }
      else
      {
         cout << "\n\nJACK:   I understand.  10 years is a long time.";
         system("pause >nul");
      }

      cout << "\n\nTHOMAS: Yeah, the time just went by, and nothing much happened for quite a while.";
      system("pause >nul");
   }
   // This choice is neutral, and doesn't affect the final outcome of the story.
   else if (choice == '2')
   {
      if (SarahAlive == 1)
      {
         cout << "\n\nSARAH:  How did you forget something as crazy as literal demons?";
         system("pause >nul");
      }
      else
      {
         cout << "\n\nJACK:   How could you forget something so important?";
         system("pause >nul");
      }

      cout << "\n\nTHOMAS: You know... it's not like I actually saw a demon or anything.\n        The time just went by, and nothing much happened for quite a while.";
      system("pause >nul");
   }

   cout << "\n\nTHOMAS: For years, there was no campsite.  Just woods.";
   system("pause >nul");

   cout << "\n\nTHOMAS: And then, the campsite was cleared out.  That's when the problems started.";
   system("pause >nul");

   cout << "\n\nBELLA:  Why do you think the zombie attacked you last night?  I mean... there are explanations for why it attacked us.";
   system("pause >nul");

   cout << "\n\nBELLA:  The zombie attacked Casey because we got too close to its home.";
   system("pause >nul");

   // Connor's death will be mentioned if he is dead.
   if (ConnorAlive == 0)
   {
      cout << "\n\nBELLA:  Connor attacked Sarah because she has a good relationship with him, and that's part of the curse.";
      system("pause >nul");
   }

   cout << "\n\nBELLA:  But why did the zombie randomly decide to attack you last night, Thomas?";
   system("pause >nul");

   cout << "\n\nTHOMAS: You have to remember... these zombies are highly intelligent.";
   system("pause >nul");

   cout << "\n\nTHOMAS: If a zombie is not too familiar with someone, the demon controlling that zombie can choose whether or not to kill that person.";
   system("pause >nul");

   cout << "\n\nTHOMAS: So... my theory is that up until now, the zombie decided that there simply wasn't a reason to attack me.";
   system("pause >nul");

   cout << "\n\nTHOMAS: However, that changed after the campsite was cleared out.\n        The zombie was probably angered by the construction of the campsite, and believed that it was my fault.";
   system("pause >nul");

   cout << "\n\n1. DOUBT: That's far-fetched..."; // Choice 1
   cout <<   "\n2. AGREE: Good explanation.";     // Choice 2

   do
   {
      cout << "\n\nChoice: ";
      cin  >> choice;
   } while (choice != '1' && choice != '2');

   // This choice is neutral, and doesn't affect the final outcome of the story.
   if (choice == '1')
   {
      // Sarah will reply to Thomas if she is alive.
      // Otherwise, Jack will reply instead.
      if (SarahAlive == 1)
      {
         cout << "\n\nSARAH:  It's possible, but that sounds a bit far-fetched.";
         system("pause >nul");
      }
      else
      {
         cout << "\n\nJACK:   I mean... that's possible, but unlikely.";
         system("pause >nul");
      }

      cout << "\n\nTHOMAS: Well, it's the best explanation I got.";
      system("pause >nul");
   }

   // This choice is neutral, and doesn't affect the final outcome of the story.
   else if (choice == '2')
   {
      // Sarah will reply to Thomas if she is alive.
      // Otherwise, Jack will reply instead.
      if (SarahAlive == 1)
      {
         cout << "\n\nSARAH:  That's the best explanation we have for now.";
         system("pause >nul");
      }
      else
      {
         cout << "\n\nJACK:   That makes sense.";
         system("pause >nul");
      }
   }

   // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");

   if (SarahAlive == 1)
   {
      cout << "Controlling: Sarah\n";
   }
   else
   {
      cout << "Controlling: Jack\n";
   }

   // Casey will speak up if he is alive.
   // Otherwise, Bella will speak up.
   if (CaseyAlive == 1)
   {
      cout << "\n\nCASEY: You know... there's probably only three or less zombies out there.";
      system("pause >nul");
   }
   else
   {
      cout << "\n\nBELLA: Ya know... there's probably only three zombies at most out there.";
      system("pause >nul");
   }

   cout << "\n\nJACK:   How would you know that?";
   system("pause >nul");

   // Casey will speak up if he is alive.
   // Otherwise, Bella will speak up.
   if (CaseyAlive == 1)
   {
      cout << "\n\nCASEY: The two disappearances, and Josie.";
      system("pause >nul");
   }
   else
   {
      cout << "\n\nBELLA: The two disappearances, and Josie.";
      system("pause >nul");
   }

   cout << "\n\nTHOMAS: You're right.  We could end this curse tonight, once and for all.";
   system("pause >nul");

   cout << "\n\nBELLA: Do you live with anyone?  Because anyone in your house right now is definitely not safe.";
   system("pause >nul");

   cout << "\n\nTHOMAS: Yeah, my wife, Cara.";
   system("pause >nul");

   // If Cara is alive, Thomas will mention that she might be in danger.
   if (CaraAlive == 1)
   {
      cout << "\n\nTHOMAS: I shouldn't have left her back at home.";
      system("pause >nul");

      cout << "\n\nTHOMAS: We need to head back before it's too late.";
      system("pause >nul");
   }

   // Otherwise, Thomas will speak about her death.
   else
   {
      cout << "\n\nTHOMAS: She died in the attack last night.";
      system("pause >nul");

      cout << "\n\nBELLA:  Oh no, I'm so sorry...";
      system("pause >nul");

      cout << "\n\nTHOMAS: It truly was awful, but she's in a better place now.\n        Let's just not talk about it.";
      system("pause >nul");

      cout << "\n\nTHOMAS: I think it would be smart to head back to my house before we do anything else.";
      system("pause >nul");
   }

   cout << "\n\n1. ENTHUSIASTIC: Let's go.";      // Option 1
   cout <<   "\n2. UNSURE:       Do we have to?"; // Option 2

   do
   {
      cout << "\n\nChoice: ";
      cin  >> choice;
   } while (choice != '1' && choice != '2');


   if (choice == '1')
   {
      // Sarah will reply to Thomas if she is alive.
      // Otherwise, Jack will reply.
      if (SarahAlive == 1)
      {
         cout << "\n\nSARAH:  Okay, let's get going!";
         system("pause >nul");
      }
      else
      {
         cout << "\n\nJACK:   Alright, let's go.";
         system("pause >nul");
      }
   }
   else if (choice == '2')
   {
      // Sarah will reply to Thomas if she is alive.
      // Otherwise, Jack will reply.
      if (SarahAlive == 1)
      {
         cout << "\n\nSARAH:  Do we have to go to your house first?";
         system("pause >nul");

         // If Sarah replies and Connor is alive, her relationship with Connor will slightly lower.
         if (ConnorAlive == 1)
         {
            cout << "\n\nCONNOR: Dude, seriously?  We are in an urgent situation right now!";
            rConnorSarah -= 1;
            system("pause >nul");
         }
         // If Sarah replies and Connor is dead, her relationship with Jack will slightly lower.
         else
         {
            cout << "\n\nJACK:   Yes, we have to go to his house first.\n        Our first priority out here is not dying.";
            rJackSarah -= 1;
            system("pause >nul");
         }
      }
      else
      {
         cout << "\n\nJACK:   Do we really need to go to your house first?";
         system("pause >nul");

         cout << "\n\nTHOMAS: Yes, we do.  You have to trust me.";
         system("pause >nul");
      }
   }

   cout << "\n\nTHOMAS: Don't worry, my house is pretty close.  I'll lead.  Bella, you bring up the rear.";
   system("pause >nul");

   cout << "\n\n        The group heads back off towards Thomas's house.";
   system("pause >nul");

   // Let the player know that chapter 4 scene 3 is complete, and
   // clear the screen, making way for a new scene.
   // IMPORTANT: If Cara is alive, there will be another scene in this chapter.
   // Otherwise, the chapter will be completed.
   cout << "\n\n        [Scene Complete.]";

   if (CaraAlive == 0)
   {
      cout << "\n\n        [Chapter 4 Complete.]";
   }

   system("pause >nul");

   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");

   /*-------------------------------------------------*/
   /*               Chapter 4, Scene 4                */
   /*-------------------------------------------------*/
   

   // This entire scene will only happen if Cara is alive.
   // This scene describes how Cara defends herself from the
   // other zombie.
   if (CaraAlive == 1)
   {
      cout << "Chapter 4, Scene 4";
      cout << "\n\nCharacters:";
      cout <<   "\nCara";
      cout << "\n\nLocation: Tom's Cabin: Bedroom\n\n";
      system("pause");
      system("cls");

      // The player will make decisions for Cara.
      cout << "Controlling: Cara\n";

      cout << "\n\n        Cara is laying down in bed and scrolling through social media on her phone in the master bedroom of Tom's Cabin.";
      system("pause >nul");

      cout << "\n\n        Suddenly, she hears a faint growling noise from outside the window.";
      system("pause >nul");

      cout << "\n\nCARA:   Please don't tell me it's that zombie again...";
      system("pause >nul");

      cout << "\n\n        Cara runs to the safe and grabs the shotgun.  She then begins to walk around the house, checking all of the windows.";
      system("pause >nul");

      cout << "\n\n        Suddenly, the sound of glass shattering comes from the bedroom, along with a horrible laugh.";
      system("pause >nul");

      cout << "\n\nCARA:   (whispering) Oh... no...";
      system("pause >nul");

      cout << "\n\n1. INVESTIGATE"; // Choice 1
      cout <<   "\n2. STAY";        // Choice 2

      do
      {
         cout << "\n\nChoice: ";
         cin  >> choice;
      } while (choice != '1' && choice != '2');

      // This choice is neutral, and doesn't affect the final outcome of the story.
      if (choice == '1')
      {
         cout << "\n\n        Cara investigates the noise.";
         system("pause >nul");

         cout << "\n\n        Cara starts to move towards the bedroom, but the zombie jumps out of the doorway almost immediately.\n        It is the same zombie that she encountered last night.";
         system("pause >nul");
      }

      // This choice is neutral, and doesn't affect the final outcome of the story.
      else if (choice == '2')
      {
         cout << "\n\n        Cara remains put.";
         system("pause >nul");

         cout << "\n\n        A few seconds later, the zombie jumps out of the doorway of the bedroom.\n        It is the same zombie that she encountered last night.";
         system("pause >nul");
      }

      // Two quick time events will happen here.  If both are passed, Cara will survive.
      // Otherwise, Cara will die.

      cout << "\n\n        The zombie starts to charge at Cara.  Cara readies her shotgun.";
      system("pause >nul");

      /* ! ! ! ! Q U I C K   T I M E   E V E N T ! ! ! ! */
      cout << "\n\n        TYPE \"BOOM\":   ";
      now = clock();
      cin >> message;

      // If the quick time event is passed, another quick time event will be triggered.
      if ((message == "BOOM" || message == "boom") && ((clock() - now) < qte_time))
      {
         cout << "\n\n        Cara hits the zombie's shoulder.  The zombie stops for a second, and continues charging at Cara.";
         system("pause >nul");

         /* ! ! ! ! Q U I C K   T I M E   E V E N T ! ! ! ! */
         cout << "\n\n        TYPE \"BANG\":   ";
         now = clock();
         cin >> message;

         // If the second quick time event is passed, Cara will survive.
         if ((message == "BANG" || message == "bang") && ((clock() - now) < qte_time))
         {
            cout << "\n\n        This shot hits the zombie straight in the head, blasting its head into pieces.";
            system("pause >nul");

            cout << "\n\nCARA:   Yeah!  Problem solved.";
            system("pause >nul");

            cout << "\n\n        Cara sits in the living room with her shotgun, waiting for Thomas to return.";
            system("pause >nul");
         }
         // If the quick time event was failed, Cara will die.
         else
         {
            cout << "\n\n        The zombie grabs Cara's face very tightly, cutting off her breathing.\n        Then, it stabs her in the stomach repeatedly with its claws, and gauges her eyes out.";
            CaraAlive = 0;
            CaraDIH = 1;
            system("pause >nul");

            cout << "\n\n        [Cara died.]";
            system("pause >nul");
         }
      }
      // If the quick time event was failed, Cara will die.
      else
      {
         cout << "\n\n        The zombie grabs Cara's face very tightly, cutting off her breathing.\n        Then, it stabs her in the stomach repeatedly with its claws, and gauges her eyes out.";
         CaraAlive = 0;
         CaraDIH = 1;
         system("pause >nul");

         cout << "\n\n        [Cara died.]";
         system("pause >nul");
      }

      // Let the player know that chapter 4 scene 4 is complete, and
      // clear the screen, making way for a new scene.
      cout << "\n\n        [Scene Complete.]";
      cout << "\n\n        [Chapter 4 Complete.]";
      system("pause >nul");

      cout << "\n\n        { CLEARING SCREEN... }";
      system("pause >nul");
      system("cls");
   }

   /*-------------------------------------------------*/
   /*               Chapter 5, Scene 1                */
   /*-------------------------------------------------*/

   // Info screen for Chapter 5, Scene 1
   cout << "Chapter 5, Scene 1";
   cout << "\n\nCharacters:";
   cout <<   "\nThomas, Jack, Bella, Casey (if alive), Connor (if alive), Sarah (if alive)";
   cout << "\n\nLocation: The woods, behind the campsite\n\n";
   system("pause");
   system("cls");

   // The player will make decisions for Bella.
   cout << "Controlling: Bella\n";

   cout << "\n\n        The group travels through the woods behind the campsite towards Thomas's house.";
   system("pause >nul");

   // If Connor is alive, he will briefly talk with Bella.
   if (ConnorAlive == 1)
   {
      cout << "\n\nCONNOR: Dude, tonight has been wild.  It's like the world has been flipped upside-down.";
      system("pause >nul");

      cout << "\n\n1. AGREE:     It definitely has..."; // Choice 1
      cout <<   "\n2. REPRIMAND: Quiet!";               // Choice 2

      do
      {
         cout << "\n\nChoice: ";
         cin  >> choice;
      } while (choice != '1' && choice != '2');

      // This choice is neutral, and doesn't affect the final outcome of the story.
      if (choice == '1')
      {
         cout << "\n\nBELLA:  For sure, it's been absolutely insane.";
         system("pause >nul");
      }
      // This choice significantly lowers Connor and Sarah's relationship.
      else if (choice == '2')
      {
         cout << "\n\nBELLA:  (whispering) Stay quiet, Connor!  We don't know what's out there.";
         system("pause >nul");

         cout << "\n\nSARAH:  (whispering) That wasn't necessary, Bella!";
         rConnorSarah += 1;
         system("pause >nul");
      }
   }

   cout << "\n\n        Bella hears the sound of footsteps behind her.\n        She turns around, but doesn't see anything.";
   system("pause >nul");

   cout << "\n\n1. WARN OTHERS"; // Choice 1
   cout <<   "\n2. IGNORE";      // Choice 2

   do
   {
      cout << "\n\nChoice: ";
      cin  >> choice;
   } while (choice != '1' && choice != '2');

   // If Bella warns the others of the noise, Jack will be able to shoot the zombie in time to save her life.
   if (choice == '1')
   {
      cout << "\n\nBELLA:  I just heard some footsteps very close behind me.";
      system("pause >nul");

      cout << "\n\nJACK:   I'll guard you so that nothing happens.";
      system("pause >nul");

      cout << "\n\n        A couple of seconds later, a zombie starts charging out of the darkness towards Bella.";
      system("pause >nul");

      cout << "\n\n        Bella recognizes it as the zombie that attacked her and Casey earlier.";
      system("pause >nul");

      cout << "\n\n        With his pistol readied, Jack fires several shots,\n        and multiple hit the zombie in the skull, killing it.";
      system("pause >nul");  
   }
   // If Bella does not warn the others of the noise, Jack will not be able to shoot the zombie in time to save her life.
   else if (choice == '2')
   {
      cout << "\n\n        Bella chooses to ignore the noise.";
      system("pause >nul");

      cout << "\n\n        A couple of seconds later, a zombie starts charging out of the darkness towards Bella.";
      system("pause >nul");

      cout << "\n\n        Bella recognizes it as the zombie that attacked her and Casey earlier.";
      system("pause >nul");

      cout << "\n\n        Jack notices, and readies his pistol, but it is too late.";
      system("pause >nul");

      cout << "\n\n        Jack finds that the zombie has already reached Bella, and it has stabbed its claws into her stomach.";
      system("pause >nul");

      // If Casey is alive, he will mourn.
      // Otherwise, Jack will mourn.
      if (CaseyAlive == 1)
      {
         cout << "\n\nCASEY:  Bella!  No!!!";
         system("pause >nul");
      }
      else
      {
         cout << "\n\nJACK:   No, Bella!";
         system("pause >nul");
      }

      cout << "\n\n        The zombie stabs Bella a few more times, and finally, Jack fires a few pistol shots into the zombie's head.";
      system("pause >nul");

      cout << "\n\n        Unfortunately, it is too late for Bella.";
      system("pause >nul");

      cout << "\n\n        [Bella died.]";
      BellaAlive = 0;
      system("pause >nul");
   }

   // The screen is cleared, and the character that the player controls switches to Jack.
   cout << "\n\n        [Switching characters...]";
   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");
   cout << "Controlling: Jack\n";

   cout << "\n\n        ...";
   system("pause >nul");

   cout << "\n\n        10 minutes later...";
   system("pause >nul");

   // If Cara is dead, they will find the zombie dragging Cara's body outside.
   // The zombie will also attack Sarah in this case, if she is alive.
   if (CaraAlive == 0)
   {
      if (CaraDIH == 1)
      {
         cout << "\n\n        Finally, the cabin comes into view.";
         system("pause >nul");

         if (SarahAlive == 1)
         {
            cout << "\n\n        Excitedly, Sarah rushes ahead.";
            system("pause >nul");
         }

         cout << "\n\n        Suddenly, a zombie comes into view inside the cabin door, dragging Cara's lifeless body outside.";
         system("pause >nul");

         cout << "\n\nTHOMAS: No!  Cara!  I knew I shouldn't have left her in there alone after last night...";
         system("pause >nul");

         if (SarahAlive == 1)
         {
            cout << "\n\n        Noticing Sarah, the zombie drops Cara's body and charges towards Sarah.";
            system("pause >nul");
         }
      }
      else
      {
         cout << "\n\n        Finally, the cabin comes into view.";
         system("pause >nul");

         if (SarahAlive == 1)
         {
            cout << "\n\n        Excitedly, Sarah rushes ahead.";
            system("pause >nul");
         }

         cout << "\n\n        Suddenly, a zombie comes into view inside the cabin door.";
         system("pause >nul");

         cout << "\n\nTHOMAS: That's the same zombie that killed Cara last night...";
         system("pause >nul");

         if (SarahAlive == 1)
         {
            cout << "\n\n        The zombie notices Sarah and begins charging towards her.";
            system("pause >nul");
         }
      }

      cout << "\n\n        Jack readies his gun and aims at the zombie.";
      system("pause >nul");

      /* ! ! ! ! Q U I C K   T I M E   E V E N T ! ! ! ! */
      cout << "\n\n        TYPE \"BLAST\":   ";
      now = clock();
      cin >> message;

      // If the quick time event is passed, Jack shoots the zombie.  If Sarah is alive, this saves her life.
      if ((message == "BLAST" || message == "blast") && ((clock() - now) < (qte_time + (int)CLOCKS_PER_SEC)))
      {
         cout << "\n\n        Jack hits the zombie in the head with his first shot.  He shoots it a couple more times to make sure that it is dead.";
         system("pause >nul");

         if (SarahAlive == 1)
         {
            cout << "\n\n        Sarah runs back to rejoin the group.";
            system("pause >nul");
         }
      }

      // If the quick time event is failed, Jack tries to shoot the zombie, but misses a few times.
      // If Sarah is alive, the zombie will kill her.  Jack still manages to kill the zombie as it runs away.
      else
      {
         if (SarahAlive == 1)
         {
            cout << "\n\n        Jack misses his first few pistol shots, giving the zombie enough\n        time to stab its powerful claws through either side of Sarah's head.";
            SarahAlive = 0;
            system("pause >nul");

            cout << "\n\n        Sarah's body falls to the ground, clearly dead.";
            system("pause >nul");

            if (ConnorAlive == 1)
            {
               cout << "\n\nCONNOR: No... Sarah!";
               system("pause >nul");
            }

            cout << "\n\n        [Sarah died.]";
            system("pause >nul");

            cout << "\n\n        As the zombie gets closer, Jack hits it square in the head, knocking it down.\n        He shoots it a few more times to make sure that it is dead.";
            system("pause >nul");
         }
         else
         {
            cout << "\n\n        Jack misses his first few shots, but as the zombie runs off, he hits it square in the head, knocking it down.\n        He shoots it a few more times to make sure that it is dead.";
            system("pause >nul");
         }  
      }

      cout << "\n\n        The group finally reaches the cabin.";
      system("pause >nul");
   }

   // If Cara is alive, the group is greeted by her as they arrive to the cabin.
   else
   {
      cout << "\n\n        The group finally reaches the cabin, and they are greeted by Cara as they arrive.";
      system("pause >nul");

      cout << "\n\nTHOMAS: I was so worried about you, Cara!";
      system("pause >nul");

      cout << "\n\nCARA:   I was worried, too.";
      system("pause >nul");

      cout << "\n\nTHOMAS: Oh no, did something happen?";
      system("pause >nul");

      cout << "\n\nCARA:   That same zombie from last night returned, but this time, I killed it.";
      system("pause >nul");

      cout << "\n\n        Cara shows the group inside, where the zombie's corpse is laying on the floor.";
      system("pause >nul");

      cout << "\n\nCARA:   What do you make of that, guys?";
      system("pause >nul");

      cout << "\n\n1. DISGUSTED: Nasty stuff.";     // Choice 1
      cout <<   "\n2. SHOCKED:   You killed that?"; // Choice 2

      do
      {
         cout << "\n\nChoice: ";
         cin  >> choice;
      } while (choice != '1' && choice != '2');

      // This choice is neutral, and doesn't affect the final outcome of the story.
      if (choice == '1')
      {
         cout << "\n\nJACK:   Honestly, it looks pretty nasty.";
         system("pause >nul");

         if (ConnorAlive == 1)
         {
            cout << "\n\nCONNOR: Agreed, man.";
            system("pause >nul");
         }
         else if (SarahAlive == 1)
         {
            cout << "\n\nSARAH:  Sure does.";
            system("pause >nul");
         }
      }

      // This choice is neutral, and doesn't affect the final outcome of the story.
      else if (choice == '2')
      {
         cout << "\n\nJACK:   You killed... that?";
         system("pause >nul");

         cout << "\n\nCARA:   Yep.";
         system("pause >nul");

         if (ConnorAlive == 1)
         {
            cout << "\n\nCONNOR: Wild, man.";
            system("pause >nul");
         }
         else if (SarahAlive == 1)
         {
            cout << "\n\nSARAH:  That's crazy...";
            system("pause >nul");
         }
      }
   }

   cout << "\n\nTHOMAS: The only one left to deal with now is Josie.";
   system("pause >nul");

   // Let the player know that chapter 5 scene 1 is complete, and
// clear the screen, making way for a new scene.
   cout << "\n\n        [Scene Complete.]";
   system("pause >nul");

   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");

   /*-------------------------------------------------*/
   /*               Chapter 5, Scene 2                */
   /*-------------------------------------------------*/
   
   cout << "Chapter 5, Scene 2";
   cout << "\n\nCharacters:";
   cout <<   "\nThomas, Jack, Bella (if alive), Casey (if alive), Sarah (if alive), Connor (if alive), Cara (if alive)";
   cout << "\n\nLocation: Tom's Cabin: Living Room\n\n";
   system("pause");
   system("cls");

   // This scene does not involve any player decisions.
   cout << "Not controlling anyone.  This scene plays out according to previous decisions.\n";

   cout << "\n\nTHOMAS: If we could only track down Josie's location...";
   system("pause >nul");

   // If Casey and Bella are both dead, the story ends, since no one else knows
   // where Josie's hideout is.
   if (CaseyAlive == 0 && BellaAlive == 0)
   {
      cout << "\n\nJACK:   Casey or Bella would've known the way.  They're both gone now though...";
      system("pause >nul");

      cout << "\n\nTHOMAS: You're right.  There's really nothing we can do.\n        Let's just call the police, and get the remaining survivors out of here.";
      system("pause >nul");
   }
   // If Casey or Bella are alive, they mention that they know where Josie is hiding out.
   else
   {
      // Casey speaks up if he is alive.  Otherwise, Bella speaks up.
      if (CaseyAlive == 1)
      {
         cout << "\n\nCASEY:  The trapdoor that the zombie went back to earlier when it dragged me off... that has to be it.";
         system("pause >nul");

         cout << "\n\nCASEY:  I could probably remember the way there from the campsite.";
         system("pause >nul");
      }
      else if (BellaAlive == 1)
      {
         cout << "\n\nBELLA:  The trapdoor that the zombie dragged Casey to... that has to be it.";
         system("pause >nul");

         cout << "\n\nBELLA:  I still remember how to get there from the campsite.";
         system("pause >nul");
      }

      cout << "\n\nTHOMAS: Okay, let's finish this off once and for all.  No more unnecessary death.";
      system("pause >nul");

      cout << "\n\nJACK:   I'll go with you.  I have my pistol.";
      system("pause >nul");

      cout << "\n\nTHOMAS: Great, and I have my shotgun.";
      system("pause >nul");

      // If Casey is alive, he will always offer to lead the way.
      // If Bella is alive but Casey is dead, then Bella will offer to lead the way.
      // If both are alive, Bella will also reply to Casey.
      if (CaseyAlive == 1 && BellaAlive == 0)
      {
         cout << "\n\nCASEY:  I'll lead the way.";
         system("pause >nul");
      }
      if (CaseyAlive == 0 && BellaAlive == 1)
      {
         cout << "\n\nBELLA:  I'll lead the way.";
         system("pause >nul");
      }
      if (CaseyAlive == 1 && BellaAlive == 1)
      {
         cout << "\n\nCASEY:  I'll lead the way.";
         system("pause >nul");

         cout << "\n\nBELLA:  And I'll follow right behind you.";
         system("pause >nul");
      }

      // Cara, Connor, and Sarah will always stay behind.
      // Whoever is left of the three of them will stay behind during the final scene.
      if ((CaraAlive == 1) || (ConnorAlive == 1) || (SarahAlive == 1))
      {
         if ((CaraAlive == 1) && (ConnorAlive == 0) && (SarahAlive == 0))
         {
            cout << "\n\nTHOMAS: Cara, you stay behind.\n        We need someone alive to tell the tale if we don't make it.";
            system("pause >nul");

            cout << "\n\nCARA:   Okie-dokie.";
            system("pause >nul");
         }
         else if ((CaraAlive == 0) && (ConnorAlive == 1) && (SarahAlive == 0))
         {
            cout << "\n\nTHOMAS: Connor, you stay behind.\n        We need someone alive to tell the tale if we don't make it.";
            system("pause >nul");

            cout << "\n\nCONNOR: Okay, man.";
            system("pause >nul");
         }
         else if ((CaraAlive == 0) && (ConnorAlive == 0) && (SarahAlive == 1))
         {
            cout << "\n\nTHOMAS: Sarah, you stay behind.\n        We need someone alive to tell the tale if we don't make it.";
            system("pause >nul");

            cout << "\n\nSARAH:  Alrighty.";
            system("pause >nul");
         }
         else
         {
            cout << "\n\nTHOMAS: The rest of you, you stay behind.\n        We need someone alive to tell the tale if we don't make it.";
            system("pause >nul");
         }
      }

      // The narrator will tell which characters go on the final adventure.
      // This may or may not include Casey and/or Bella.
      cout << "\n\n        And so... Thomas, Jack, ";
      if ((CaseyAlive == 1) && (BellaAlive == 1))
      {
         cout << "Casey, and Bella set out to track down Josie, and end this curse once and for all.";
      }

      if ((CaseyAlive == 1) && (BellaAlive == 0))
      {
         cout << "and Casey set out to track down Josie, and end this curse once and for all.";
      }

      if ((CaseyAlive == 0) && (BellaAlive == 1))
      {
         cout << "and Bella set out to track down Josie, and end this curse once and for all.";
      }
      system("pause >nul");
   }
   // Let the player know that chapter 5 scene 2 is complete.
   // If Casey and Bella are dead, the game ends here.
   // Otherwise, clear the screen to make way for a new scene.
   cout << "\n\n        [Scene Complete.]";
   
   if (CaseyAlive == 1 || BellaAlive == 1)
   {
      cout << "\n\n        { CLEARING SCREEN... }";
      system("pause >nul");
      system("cls");

      /*-------------------------------------------------*/
      /*               Chapter 5, Scene 3                */
      /*-------------------------------------------------*/

      // Info screen for Chapter 5, Scene 3
      cout << "Chapter 5, Scene 3";
      cout << "\n\nCharacters:";
      cout <<   "\nThomas, Jack, Bella (if alive), Casey (if alive)";
      cout << "\n\nLocation: The woods behind the campsite / Josie's Cave\n\n";
      system("pause");
      system("cls");

      // The player will make decisions for Thomas.
      cout << "Controlling: Thomas\n";

      cout << "\n\n";
      system("pause >nul");

      // Casey (default) or Bella will lead the way to the trapdoor.
      if (CaseyAlive == 1)
      {
         cout << "\n\nCASEY:  I think that the trapdoor was right around this clearing.";
         system("pause >nul");

         cout << "\n\nCASEY:  ...";
         system("pause >nul");

         cout << "\n\nCASEY:  That odd-looking stick... that's the handle.";
         system("pause >nul");

         cout << "\n\n        Casey pulls on the handle of the trapdoor.";
         system("pause >nul");

         cout << "\n\n        It lifts up a few inches, revealing a padlock.";
         system("pause >nul");

         cout << "\n\nCASEY:  Aw man, it's locked.";
         system("pause >nul");
      }
      else
      {
         if (BellaAlive == 1)
         {
            cout << "\n\nBELLA:  The trapdoor was right around this clearing.";
            system("pause >nul");

            cout << "\n\nBELLA:  ...";
            system("pause >nul");

            cout << "\n\nBELLA:  That odd-looking stick... that's the handle.";
            system("pause >nul");

            cout << "\n\n        Bella pulls on the handle of the trapdoor.";
            system("pause >nul");

            cout << "\n\n        It lifts up a few inches, revealing a padlock.";
            system("pause >nul");

            cout << "\n\nBELLA:  Aw man, it's locked.";
            system("pause >nul");
         }
      }

      cout << "\n\nJACK:   I've got my pistol.  A few shots should do.";
      system("pause >nul");

      cout << "\n\n        Jack shoots the padlock, breaking it.\n        Then, he lifts up the trapdoor, and peers inside.";
      system("pause >nul");

      cout << "\n\n        Inside is a ladder, leading down to a small cave.";
      system("pause >nul");

      cout << "\n\nJACK:   Woah, there's a whole cave in there!";
      system("pause >nul");

      cout << "\n\nTHOMAS: This has to be it.  This is the perfect spot to hide.";
      system("pause >nul");

      cout << "\n\nTHOMAS: I'll go down first, you guys follow.";
      system("pause >nul");

      cout << "\n\n        The group descends into the cave.";
      system("pause >nul");

      cout << "\n\n        The cave is dimly lit with torches.\n        Footsteps can be heard coming from around the corner.";
      system("pause >nul");

      cout << "\n\n        As Thomas readies his shotgun, Josie comes into view, looking emaciated, yet scarier than ever.\n        She holds a long spear in her left hand.";
      system("pause >nul");

      // Nothing changes in the story here, the screen is just cleared to keep the UI neat.
      cout << "\n\n        { CLEARING SCREEN... }";
      system("pause >nul");
      system("cls");
      cout << "Controlling: Thomas\n";

      cout << "\n\nJOSIE:  Thomas, have you come to kill me?";
      system("pause >nul");

      cout << "\n\n1. NEGOTIATE: End this curse now."; // Choice 1
      cout <<   "\n2. TRUTHFUL:  Yes.";                // Choice 2

      do
      {
         cout << "\n\nChoice: ";
         cin  >> choice;
      } while (choice != '1' && choice != '2');

      // This choice is neutral, and doesn't affect the final outcome of the story.
      if (choice == '1')
      {
         cout << "\n\nTHOMAS: If you end this curse now, I will let you live.";
         system("pause >nul");

         cout << "\n\nJOSIE:  (laughs) Oh, how foolish of you to ask.  Did you forget?\n        Once a curse is put into effect, the only way to end it... is to kill whoever started the curse.";
         system("pause >nul");

         cout << "\n\nTHOMAS: Well, then... there's only one remaining option.";
         system("pause >nul");
      }

      // This choice is neutral, and doesn't affect the final outcome of the story.
      else if (choice == '2')
      {
         cout << "\n\nTHOMAS: What else would I be here for?.";
         system("pause >nul");

         cout << "\n\nJOSIE:  I didn't think you would be strong enough to admit that.";
         system("pause >nul");
      }

      cout << "\n\nJOSIE:  While I was down here, I trained for years in sorcery and witchcraft.  You all stand no chance.";
      system("pause >nul");

      cout << "\n\nJOSIE:  Prepare... to meet your maker!";
      system("pause >nul");

      cout << "\n\n        Josie closes her eyes as if to concentrate.  Out of nowhere, a ball of energy starts forming over her head.";
      system("pause >nul");

      cout << "\n\n1. SHOOT AT JOSIE";              // Choice 1
      cout <<   "\n2. SHOOT AT THE BALL OF ENERGY"; // Choice 2

      do
      {
         cout << "\n\nChoice: ";
         cin  >> choice;
      } while (choice != '1' && choice != '2');

      // Since the ball of energy renders Josie invincible, shooting at Josie will waste valuable time, causing her to gain enough time to kill Thomas.
      if (choice == '1')
      {
         cout << "\n\n        Thomas shoots at Josie.  The shot hits an invisible forcefield in front of Josie and bounces right off.";
         system("pause >nul");

         cout << "\n\nJOSIE:  You really thought that would work?";
         system("pause >nul");

         cout << "\n\n        Josie releases the ball of energy, and it flies towards Thomas.";
         system("pause >nul");

         cout << "\n\n        As soon as the ball of energy hits Thomas, it disappears.";
         system("pause >nul");

         cout << "\n\nTHOMAS: I... don't...";
         system("pause >nul");

         cout << "\n\n        Suddenly, Thomas's entire body explodes, and guts spray all over the room.";
         ThomasAlive = 0;
         system("pause >nul");

         cout << "\n\n        [Thomas died.]";
         system("pause >nul");

         cout << "\n\nJOSIE:  HAHAHA!  Wait a minute... I don't have energy left to charge another one.";
         system("pause >nul");
      }
      // Shooting at the ball of energy will shatter it, leaving Josie vulnerable.
      else if (choice == '2')
      {
         cout << "\n\n        Thomas shoots at the ball of energy.  It shatters and breaks, just like a glass vase.";
         system("pause >nul");

         cout << "\n\nJOSIE:  NO!!  WHAT?  How did you know to do that?";
         system("pause >nul");

         cout << "\n\n        Angered, Josie charges at Thomas with her spear.";
         system("pause >nul");

         /* ! ! ! ! Q U I C K   T I M E   E V E N T ! ! ! ! */
         cout << "\n\n        TYPE \"SHOTGUN\":   ";
         now = clock();
         cin >> message;

         // Thomas kills Josie, ending the game.
         if ((message == "SHOTGUN" || message == "shotgun") && ((clock() - now) < (qte_time + (int)CLOCKS_PER_SEC)))
         {
            cout << "\n\n        Thomas shoots Josie with the shotgun.  The shot hits her in the head, blasting a hole in her face.";
            JosieAlive = 0;
            system("pause >nul");

            cout << "\n\nTHOMAS: ...";
            system("pause >nul");

            cout << "\n\nTHOMAS: It's over now.  Let's get back to the others.";
            system("pause >nul");
         }

         // Thomas does not shoot in time, and dies.
         else
         {
            cout << "\n\n        Thomas doesn't aim his shotgun in time to shoot Josie.";
            ThomasAlive = 0;
            system("pause >nul");

            cout << "\n\n        Josie runs up to him and spears him through the chest.";
            system("pause >nul");

            cout << "\n\n        [Thomas died.]";
            system("pause >nul");
         }
      }

      // If Josie is still alive, continue the battle.
      if (JosieAlive == 1)
      {
         // The screen is cleared, and the character that the player controls switches to Jack.
         cout << "\n\n        [Switching characters...]";
         cout << "\n\n        { CLEARING SCREEN... }";
         system("pause >nul");
         system("cls");
         cout << "Controlling: Jack\n";

         cout << "\n\n        Josie turns towards Jack and charges at him.";
         system("pause >nul");

         /* ! ! ! ! Q U I C K   T I M E   E V E N T ! ! ! ! */
         cout << "\n\n        TYPE \"PISTOL\":   ";
         now = clock();
         cin >> message;

         // Jack kills Josie, ending the game.
         if ((message == "PISTOL" || message == "pistol") && ((clock() - now) < (qte_time + (int)CLOCKS_PER_SEC)))
         {
            cout << "\n\n        Jack shoots Josie with the pistol.\n        The shot hits her in the forehead, knocking her down and instantly killing her.";
            JosieAlive = 0;
            system("pause >nul");

            cout << "\n\nJACK:   ...";
            system("pause >nul");

            cout << "\n\nJACK:   It's over now.  We'd better get back to the others.";
            system("pause >nul");
         }
         // Jack does not shoot in time, and dies.
         else
         {
            cout << "\n\n        Jack can't aim his pistol in time.";
            system("pause >nul");

            cout << "\n\n        Josie grabs Jack's throat and spears him through the chest.\n        Jack's lifeless body falls to the ground.";
            JackAlive = 0;
            system("pause >nul");

            cout << "\n\n        [Jack died.]";
            system("pause >nul");
         }
      }

      // If Josie is still alive, continue the battle.
      if (JosieAlive == 1)
      {
         // The screen is cleared, and the character that the player controls switches to Bella (default),
         // or Casey, depending on who is alive.
         cout << "\n\n        [Switching characters...]";
         cout << "\n\n        { CLEARING SCREEN... }";
         system("pause >nul");
         system("cls");

         if (BellaAlive == 1)
         {
            cout << "Controlling: Bella\n";
         }
         else
         {
            cout << "Controlling: Casey\n";
         }

         // Josie will turn to attack Bella, if Bella is alive.
         // Otherwise, Josie will turn to attack Casey.
         if ((CaseyAlive == 1) && (BellaAlive == 1))
         {
            cout << "\n\n        Josie turns towards Bella.";
            system("pause >nul");

            cout << "\n\nCASEY:  Watch out, Bella!";
            system("pause >nul");

            cout << "\n\n        Bella grabs the taser out of her pocket.";
            system("pause >nul");
         }

         if ((CaseyAlive == 1) && (BellaAlive == 0))
         {
            cout << "\n\n        Josie turns towards Casey.";
            system("pause >nul");

            cout << "\n\n        Casey remembers that he picked up Bella's taser from earlier.";
            system("pause >nul");
         }

         if ((CaseyAlive == 0) && (BellaAlive == 1))
         {
            cout << "\n\n        Josie turns towards Bella.";
            system("pause >nul");

            cout << "\n\n        Bella grabs the taser out of her pocket.";
            system("pause >nul");
         }

         /* ! ! ! ! Q U I C K   T I M E   E V E N T ! ! ! ! */
         cout << "\n\n        TYPE \"SHOCK\":   ";
         now = clock();
         cin >> message;

         // If the quick time event is passed, and Bella is alive, Bella returns to the cabin with or without Casey.
         // If Bella is dead and Casey is alive, then one of two scenarios will happen:
         //       1. If Casey was injured earlier from being shot through the bush, he will be too
         //          weak to defend himself, and he will die.
         //       2. Otherwise, Casey will shoot Josie, ending the game.
         if ((message == "SHOCK" || message == "shock") && ((clock() - now) < (qte_time + (int)CLOCKS_PER_SEC)))
         {
            if ((CaseyAlive == 1) && (BellaAlive == 1))
            {
               cout << "\n\n        Bella shocks Josie with the taser.\n        This gives Casey an opening to grab Jack's pistol and fire a few rounds into Josie's head.";
               JosieAlive = 0;
               system("pause >nul");

               cout << "\n\nBELLA:  We did it... let's head back, Casey.";
               system("pause >nul");
            }

            if ((CaseyAlive == 1) && (BellaAlive == 0))
            {
               if (CaseyInjured == 1)
               {
                  cout << "\n\n        Casey reaches for the taser, but his shoulder is injured from Jack shooting him earlier.";
                  CaseyAlive = 0;
                  system("pause >nul");

                  cout << "\n\n        Casey lets out a pained scream, and is not able to grab the taser.";
                  system("pause >nul");

                  cout << "\n\n        Josie grabs Casey by the face and bashes his head repeatedly into the cave wall.";
                  system("pause >nul");

                  cout << "\n\n        [Casey died.]";
                  system("pause >nul");

                  cout << "\n\nJOSIE:  (laughs) They thought they could stop me?  Hmph.";
                  system("pause >nul");
               }
               else
               {
                  cout << "\n\n        Casey shocks Josie with the taser.\n        This gives him an opening to grab Jack's pistol and fire a few rounds into Josie's head.";
                  JosieAlive = 0;
                  system("pause >nul");

                  cout << "\n\n        With everyone else dead, Casey heads back alone to meet the others.";
                  system("pause >nul");
               }
            }

            if ((CaseyAlive == 0) && (BellaAlive == 1))
            {
               cout << "\n\n        Bella shocks Josie with the taser.\n        This gives her an opening to grab Jack's pistol and fire a few rounds into Josie's head.";
               JosieAlive = 0;
               system("pause >nul");

               cout << "\n\n        With everyone else dead, Bella heads back alone to meet the others.";
               system("pause >nul");
            }
         }
         // If the quick time event is failed, both Bella and Casey will die, regardless of their status beforehand.
         else
         {
            if ((CaseyAlive == 1) && (BellaAlive == 1))
            {
               cout << "\n\n        Bella isn't able to use the taser in time.";
               BellaAlive = 0;
               system("pause >nul");

               cout << "\n\n        Josie stabs Bella with the spear, throws her body to the ground, and spears her again.";
               system("pause >nul");

               cout << "\n\n        [Bella died.]";
               system("pause >nul");

               cout << "\n\nCASEY:  NO!!!";
               system("pause >nul");

               cout << "\n\n        Casey scrambles to grab the shotgun, but there is not enough time.";
               CaseyAlive = 0;
               system("pause >nul");

               cout << "\n\n        Josie spears Casey, and bashes his head into the cave wall.";
               system("pause >nul");

               cout << "\n\n        [Casey died.]";
               system("pause >nul");

               cout << "\n\nJOSIE:  (laughs) They thought they could stop me?  Hmph.";
               system("pause >nul");
            }

            if ((CaseyAlive == 1) && (BellaAlive == 0))
            {
               cout << "\n\n        Casey isn't able to use the taser in time.";
               CaseyAlive = 0;
               system("pause >nul");

               cout << "\n\n        Josie spears Casey, and bashes his head into the cave wall.";
               system("pause >nul");

               cout << "\n\n        [Casey died.]";
               system("pause >nul");

               cout << "\n\nJOSIE:  (laughs) They thought they could stop me?  Hmph.";
               system("pause >nul");
            }

            if ((CaseyAlive == 0) && (BellaAlive == 1))
            {
               cout << "\n\n        Bella isn't able to use the taser in time.";
               BellaAlive = 0;
               system("pause >nul");

               cout << "\n\n        Josie stabs Bella with the spear, throws her body to the ground, and spears her again.";
               system("pause >nul");

               cout << "\n\n        [Bella died.]";
               system("pause >nul");

               cout << "\n\nJOSIE:  (laughs) They thought they could stop me?  Hmph.";
               system("pause >nul");
            }
         }
      }
      // Let the player know that chapter 5, scene 3 is complete.
      cout << "\n\n        [Scene Complete.]";
   }

   // Here, the end of the story will be reached, no matter what.
   cout << "\n\n        [Chapter Complete.]";
   system("pause >nul");

   cout << "\n\n        [ STORY COMPLETE. ]";
   system("pause >nul");

   cout << "\n\n        { CLEARING SCREEN... }";
   system("pause >nul");
   system("cls");

   // Show results screen
   cout << "\n\nRESULTS:";

   // Print main character statuses (whether each main character is alive or dead)
   cout << "\n\nCharacter Status:";
   cout <<   "\n-----------------";

   cout <<   "\nThomas:   ";
   if (ThomasAlive == 1)
   {
      cout <<   "Alive";
   }
   else
   {
      cout <<   "Dead";
   }

   cout <<   "\nCara:   ";
   if (CaraAlive == 1)
   {
      cout <<   "Alive";
   }
   else
   {
      cout <<   "Dead";
   }

   cout <<   "\nJack:   ";
   if (JackAlive == 1)
   {
      cout <<   "Alive";
   }
   else
   {
      cout <<   "Dead";
   }

   cout <<   "\nCasey:   ";
   if (CaseyAlive == 1)
   {
      cout <<   "Alive";
   }
   else
   {
      cout <<   "Dead";
   }

   cout <<   "\nBella:   ";
   if (BellaAlive == 1)
   {
      cout <<   "Alive";
   }
   else
   {
      cout <<   "Dead";
   }

   cout <<   "\nConnor:   ";
   if (ConnorAlive == 1)
   {
      cout <<   "Alive";
   }
   else
   {
      cout <<   "Dead";
   }

   cout <<   "\nSarah:   ";
   if (SarahAlive == 1)
   {
      cout <<   "Alive";
   }
   else
   {
      cout <<   "Dead";
   }

   // Print side character statuses (whether each side character is alive or dead)
   cout << "\n\nSide Character Status:";
   cout <<   "\n----------------------";

   cout <<   "\nJames:   ";
   if (JamesAlive == 1)
   {
      cout <<   "Alive";
   }
   else
   {
      cout <<   "Dead";
   }

   cout <<   "\nJosie:   ";
   if (JosieAlive == 1)
   {
      cout <<   "Alive";
   }
   else
   {
      cout <<   "Dead";
   }

   // Print relationship statuses (whether each relationship increased, decreased, or was broken by death)
   cout << "\n\nRelationships:";
   cout <<   "\n--------------";

   cout <<   "\n\nThomas and Cara:\n   ";
   if (ThomasAlive == 1 && CaraAlive == 1)
   {
      if (rThomasCara <= -2)
      {
         cout << "Thomas and Cara's relationship got much worse over the course of the night.";
      }

      if (rThomasCara == -1)
      {
         cout << "Thomas and Cara's relationship got slightly worse over the course of the night.";
      }

      if (rThomasCara == 0)
      {
         cout << "Thomas and Cara's relationship stayed the same over the course of the night.";
      }

      if (rThomasCara == 1)
      {
         cout << "Thomas and Cara's relationship got slightly better over the course of the night.";
      }

      if (rThomasCara >= 2)
      {
         cout << "Thomas and Cara's relationship got much better over the course of the night.";
      }
   }
   else
   {
      cout << "Thomas and Cara's relationship was broken, because one of these characters died.";
   }

   cout <<   "\n\nJack and Connor:\n   ";
   if (JackAlive == 1 && ConnorAlive == 1)
   {
      if (rJackConnor <= -2)
      {
         cout << "Jack and Connor's relationship got much worse over the course of the night.";
      }

      if (rJackConnor == -1)
      {
         cout << "Jack and Connor's relationship got slightly worse over the course of the night.";
      }

      if (rJackConnor == 0)
      {
         cout << "Jack and Connor's relationship stayed the same over the course of the night.";
      }

      if (rJackConnor == 1)
      {
         cout << "Jack and Connor's relationship got slightly better over the course of the night.";
      }

      if (rJackConnor >= 2)
      {
         cout << "Jack and Connor's relationship got much better over the course of the night.";
      }
   }
   else
   {
      cout << "Jack and Connor's relationship was broken, because one of these characters died.";
   }

   cout <<   "\n\nCasey and Bella:\n   ";
   if (CaseyAlive == 1 && BellaAlive == 1)
   {
      if (rCaseyBella <= -2)
      {
         cout << "Casey and Bella's relationship got much worse over the course of the night.";
      }

      if (rCaseyBella == -1)
      {
         cout << "Casey and Bella's relationship got slightly worse over the course of the night.";
      }

      if (rCaseyBella == 0)
      {
         cout << "Casey and Bella's relationship stayed the same over the course of the night.";
      }

      if (rCaseyBella == 1)
      {
         cout << "Casey and Bella's relationship got slightly better over the course of the night.";
      }

      if (rCaseyBella >= 2)
      {
         cout << "Casey and Bella's relationship got much better over the course of the night.";
      }
   }
   else
   {
      cout << "Casey and Bella's relationship was broken, because one of these characters died.";
   }

   cout <<   "\n\nCasey and The Boys (Jack and Connor):\n   ";
   if (CaseyAlive == 1 && JackAlive == 1 && ConnorAlive == 1)
   {
      if (rCaseyBoys <= -2)
      {
         cout << "Casey and Jack & Connor's relationship got much worse over the course of the night.";
      }

      if (rCaseyBoys == -1)
      {
         cout << "Casey and Jack & Connor's relationship got slightly worse over the course of the night.";
      }

      if (rCaseyBoys == 0)
      {
         cout << "Casey and Jack & Connor's relationship stayed the same over the course of the night.";
      }

      if (rCaseyBoys == 1)
      {
         cout << "Casey and Jack & Connor's relationship got slightly better over the course of the night.";
      }

      if (rCaseyBoys >= 2)
      {
         cout << "Casey and Jack & Connor's relationship got much better over the course of the night.";
      }
   }
   else
   {
      cout << "Casey and Jack & Connor's relationship was broken, because one of these characters died.";
   }

   cout <<   "\n\nConnor and Sarah:\n   ";
   if (ConnorAlive == 1 && SarahAlive == 1)
   {
      if (rConnorSarah <= -2)
      {
         cout << "Connor and Sarah's relationship got much worse over the course of the night.";
      }

      if (rConnorSarah == -1)
      {
         cout << "Connor and Sarah's relationship got slightly worse over the course of the night.";
      }

      if (rConnorSarah == 0)
      {
         cout << "Connor and Sarah's relationship stayed the same over the course of the night.";
      }

      if (rConnorSarah == 1)
      {
         cout << "Connor and Sarah's relationship got slightly better over the course of the night.";
      }

      if (rConnorSarah >= 2)
      {
         cout << "Connor and Sarah's relationship got much better over the course of the night.";
      }
   }
   else
   {
      cout << "Connor and Sarah's relationship was broken, because one of these characters died.";
   }

   cout <<   "\n\nJack and Sarah:\n   ";
   if (JackAlive == 1 && SarahAlive == 1)
   {
      if (rJackSarah <= -2)
      {
         cout << "Jack and Sarah's relationship got much worse over the course of the night.";
      }

      if (rJackSarah == -1)
      {
         cout << "Jack and Sarah's relationship got slightly worse over the course of the night.";
      }

      if (rJackSarah == 0)
      {
         cout << "Jack and Sarah's relationship stayed the same over the course of the night.";
      }

      if (rJackSarah == 1)
      {
         cout << "Jack and Sarah's relationship got slightly better over the course of the night.";
      }

      if (rJackSarah >= 2)
      {
         cout << "Jack and Sarah's relationship got much better over the course of the night.";
      }
   }
   else
   {
      cout << "Jack and Sarah's relationship was broken, because one of these characters died.";
   }

   // Print whether the player got the good or bad ending
   if (JosieAlive == 0)
   {
      cout << "\n\n\nGOOD ENDING: You ended the curse.\n\n\n";
   }
   else
   {
      cout << "\n\n\nBAD ENDING: You failed to end the curse.\n\n\n";
   }

   // Pause the screen several times to make it difficult to unintentionally exit the game
   // without looking at the results
   system("pause >nul");
   system("pause >nul");
   system("pause >nul");
   system("pause >nul");
   system("pause >nul");
   system("pause >nul");
   system("pause >nul");
   system("pause >nul");
}